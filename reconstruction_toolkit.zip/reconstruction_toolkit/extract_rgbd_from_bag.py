#!/usr/bin/env python3
"""
从 RealSense ROS bag 文件中提取 RGB-D 数据
使用 rosbags 库（支持 lz4 压缩）
"""

import sys
import json
import struct
from pathlib import Path
import numpy as np
import cv2
from rosbags.rosbag1 import Reader


def extract_rgbd(bag_path: str, output_dir: str):
    """从 bag 文件提取 RGB-D 数据"""
    bag_path = Path(bag_path)
    output_dir = Path(output_dir)
    
    # 创建输出目录
    rgb_dir = output_dir / "rgb"
    depth_dir = output_dir / "depth"
    info_dir = output_dir / "info"
    
    for d in [rgb_dir, depth_dir, info_dir]:
        d.mkdir(parents=True, exist_ok=True)
    
    print(f"处理: {bag_path}")
    print(f"输出: {output_dir}")
    
    # 定义 topic 名称（RealSense bag 格式）
    rgb_topic = "/device_0/sensor_1/Color_0/image/data"
    depth_topic = "/device_0/sensor_0/Depth_0/image/data"
    rgb_info_topic = "/device_0/sensor_1/Color_0/info/camera_info"
    depth_info_topic = "/device_0/sensor_0/Depth_0/info/camera_info"
    
    rgb_count = 0
    depth_count = 0
    camera_info = {}
    timestamps = {"rgb": [], "depth": []}
    
    with Reader(bag_path) as reader:
        print(f"消息总数: {reader.message_count}")
        
        # 遍历所有消息
        for connection, timestamp, rawdata in reader.messages():
            topic = connection.topic
            
            if topic == rgb_topic:
                # 解析 RGB 图像
                img = parse_image_msg(rawdata)
                if img is not None:
                    filename = f"{rgb_count:06d}.png"
                    cv2.imwrite(str(rgb_dir / filename), img)
                    timestamps["rgb"].append({
                        "frame": rgb_count,
                        "timestamp": timestamp,
                        "filename": filename
                    })
                    rgb_count += 1
                    if rgb_count % 50 == 0:
                        print(f"  RGB: {rgb_count} 帧...")
                        
            elif topic == depth_topic:
                # 解析深度图像
                img = parse_image_msg(rawdata)
                if img is not None:
                    filename = f"{depth_count:06d}.png"
                    cv2.imwrite(str(depth_dir / filename), img)
                    timestamps["depth"].append({
                        "frame": depth_count,
                        "timestamp": timestamp,
                        "filename": filename
                    })
                    depth_count += 1
                    if depth_count % 50 == 0:
                        print(f"  深度: {depth_count} 帧...")
                        
            elif topic == rgb_info_topic and "rgb" not in camera_info:
                camera_info["rgb"] = parse_camera_info(rawdata)
                
            elif topic == depth_info_topic and "depth" not in camera_info:
                camera_info["depth"] = parse_camera_info(rawdata)
    
    # 保存元数据
    metadata = {
        "bag_file": str(bag_path),
        "rgb_frames": rgb_count,
        "depth_frames": depth_count,
        "camera_info": camera_info,
        "timestamps": timestamps
    }
    
    with open(info_dir / "metadata.json", "w") as f:
        json.dump(metadata, f, indent=2, default=str)
    
    print(f"\n✓ 提取完成!")
    print(f"  RGB 帧: {rgb_count}")
    print(f"  深度帧: {depth_count}")
    print(f"  元数据: {info_dir / 'metadata.json'}")
    
    return rgb_count, depth_count


def parse_image_msg(rawdata: bytes) -> np.ndarray:
    """解析 sensor_msgs/Image 消息"""
    try:
        offset = 0
        
        # Header: seq(uint32) + stamp(uint32+uint32) + frame_id(string)
        seq = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        stamp_sec = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        stamp_nsec = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        frame_id_len = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4 + frame_id_len
        
        # Image fields
        height = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        width = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        
        encoding_len = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        encoding = rawdata[offset:offset+encoding_len].decode('utf-8')
        offset += encoding_len
        
        is_bigendian = struct.unpack_from('<B', rawdata, offset)[0]
        offset += 1
        
        step = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        
        data_len = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        data = rawdata[offset:offset+data_len]
        
        # 根据编码格式解析图像
        if encoding in ['rgb8', 'bgr8']:
            img = np.frombuffer(data, dtype=np.uint8).reshape(height, width, 3)
            if encoding == 'rgb8':
                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        elif encoding in ['16UC1', 'mono16']:
            img = np.frombuffer(data, dtype=np.uint16).reshape(height, width)
        elif encoding == 'mono8':
            img = np.frombuffer(data, dtype=np.uint8).reshape(height, width)
        else:
            print(f"  未知编码: {encoding}")
            return None
            
        return img
        
    except Exception as e:
        print(f"  解析图像失败: {e}")
        return None


def parse_camera_info(rawdata: bytes) -> dict:
    """解析 sensor_msgs/CameraInfo 消息"""
    try:
        offset = 0
        
        # Header
        offset += 4  # seq
        offset += 4  # stamp_sec
        offset += 4  # stamp_nsec
        frame_id_len = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4 + frame_id_len
        
        # height, width
        height = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        width = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        
        # distortion_model
        model_len = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        distortion_model = rawdata[offset:offset+model_len].decode('utf-8')
        offset += model_len
        
        # D (distortion coefficients)
        d_len = struct.unpack_from('<I', rawdata, offset)[0]
        offset += 4
        D = list(struct.unpack_from(f'<{d_len}d', rawdata, offset))
        offset += d_len * 8
        
        # K (intrinsic matrix 3x3)
        K = list(struct.unpack_from('<9d', rawdata, offset))
        offset += 72
        
        # R (rectification matrix 3x3)
        R = list(struct.unpack_from('<9d', rawdata, offset))
        offset += 72
        
        # P (projection matrix 3x4)
        P = list(struct.unpack_from('<12d', rawdata, offset))
        
        return {
            "height": height,
            "width": width,
            "distortion_model": distortion_model,
            "D": D,
            "K": K,
            "R": R,
            "P": P,
            "fx": K[0],
            "fy": K[4],
            "cx": K[2],
            "cy": K[5]
        }
        
    except Exception as e:
        print(f"  解析相机信息失败: {e}")
        return {}


def main():
    if len(sys.argv) < 3:
        print("用法: python extract_rgbd_from_bag.py <bag文件> <输出目录>")
        print("示例: python extract_rgbd_from_bag.py recording.bag ./output")
        sys.exit(1)
    
    bag_file = sys.argv[1]
    output_dir = sys.argv[2]
    
    if not Path(bag_file).exists():
        print(f"错误: 文件不存在 - {bag_file}")
        sys.exit(1)
    
    extract_rgbd(bag_file, output_dir)


if __name__ == "__main__":
    main()
