#!/usr/bin/env python3
"""
基于RealSense RGBD数据的桌面物体三维重建
用于从RGBD图像序列生成点云，检测桌面平面，分割并定位物体
"""

import open3d as o3d
import numpy as np
import json
from pathlib import Path
import cv2
from typing import Tuple, List, Dict
import argparse


class RGBDReconstructor:
    """RGBD数据重建器"""
    
    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self.rgb_dir = self.data_dir / "rgb"
        self.depth_dir = self.data_dir / "depth"
        self.info_dir = self.data_dir / "info"
        
        # 加载相机内参
        self.load_camera_info()
        
        # 创建输出目录
        self.output_dir = self.data_dir / "rgbd_reconstruction"
        self.output_dir.mkdir(exist_ok=True)
        
    def load_camera_info(self):
        """从metadata.json加载相机内参"""
        metadata_file = self.info_dir / "metadata.json"
        with open(metadata_file, 'r') as f:
            metadata = json.load(f)
        
        # RGB相机内参
        rgb_info = metadata['camera_info']['rgb']
        self.rgb_width = rgb_info['width']
        self.rgb_height = rgb_info['height']
        self.rgb_fx = rgb_info['fx']
        self.rgb_fy = rgb_info['fy']
        self.rgb_cx = rgb_info['cx']
        self.rgb_cy = rgb_info['cy']
        
        # 深度相机内参
        depth_info = metadata['camera_info']['depth']
        self.depth_width = depth_info['width']
        self.depth_height = depth_info['height']
        self.depth_fx = depth_info['fx']
        self.depth_fy = depth_info['fy']
        self.depth_cx = depth_info['cx']
        self.depth_cy = depth_info['cy']
        
        # 创建Open3D相机内参对象（使用RGB相机参数）
        self.intrinsic = o3d.camera.PinholeCameraIntrinsic(
            width=self.rgb_width,
            height=self.rgb_height,
            fx=self.rgb_fx,
            fy=self.rgb_fy,
            cx=self.rgb_cx,
            cy=self.rgb_cy
        )
        
        print(f"✓ 相机内参加载成功:")
        print(f"  RGB: {self.rgb_width}x{self.rgb_height}, fx={self.rgb_fx:.2f}, fy={self.rgb_fy:.2f}")
        print(f"  Depth: {self.depth_width}x{self.depth_height}, fx={self.depth_fx:.2f}, fy={self.depth_fy:.2f}")
        
    def load_rgbd_frame(self, frame_idx: int, depth_scale: float = 1000.0) -> o3d.geometry.RGBDImage:
        """
        加载单帧RGBD图像
        
        Args:
            frame_idx: 帧索引
            depth_scale: 深度缩放因子（RealSense通常是1000，即1mm单位）
        """
        rgb_file = self.rgb_dir / f"{frame_idx:06d}.png"
        depth_file = self.depth_dir / f"{frame_idx:06d}.png"
        
        if not rgb_file.exists() or not depth_file.exists():
            return None
        
        # 加载RGB和深度图像
        color_cv = cv2.imread(str(rgb_file))
        depth_cv = cv2.imread(str(depth_file), cv2.IMREAD_UNCHANGED)
        
        # 如果深度图像尺寸与RGB不匹配，进行缩放对齐
        if depth_cv.shape[:2] != (self.rgb_height, self.rgb_width):
            # 将深度图从848x480缩放到640x480
            depth_cv = cv2.resize(depth_cv, (self.rgb_width, self.rgb_height), 
                                 interpolation=cv2.INTER_NEAREST)
        
        # 转换为Open3D格式
        color = o3d.geometry.Image(cv2.cvtColor(color_cv, cv2.COLOR_BGR2RGB))
        depth = o3d.geometry.Image(depth_cv)
        
        # 创建RGBD图像
        rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
            color,
            depth,
            depth_scale=depth_scale,
            depth_trunc=3.0,  # 截断超过3米的深度
            convert_rgb_to_intensity=False
        )
        
        return rgbd
    
    def rgbd_to_pointcloud(self, frame_idx: int, depth_scale: float = 1000.0) -> o3d.geometry.PointCloud:
        """
        将单帧RGBD转换为点云
        
        Args:
            frame_idx: 帧索引
            depth_scale: 深度缩放因子
        """
        rgbd = self.load_rgbd_frame(frame_idx, depth_scale)
        if rgbd is None:
            return None
        
        # 生成点云
        pcd = o3d.geometry.PointCloud.create_from_rgbd_image(
            rgbd,
            self.intrinsic
        )
        
        return pcd
    
    def reconstruct_single_frame(self, frame_idx: int = 0, save: bool = True):
        """
        重建单帧点云（用于快速测试）
        
        Args:
            frame_idx: 要重建的帧索引
            save: 是否保存结果
        """
        print(f"\n=== 重建单帧点云 (帧 {frame_idx}) ===")
        
        pcd = self.rgbd_to_pointcloud(frame_idx)
        
        if pcd is None:
            print(f"✗ 无法加载帧 {frame_idx}")
            return None
        
        print(f"✓ 点云生成成功: {len(pcd.points)} 个点")
        
        # 移除离群点
        pcd, _ = pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
        print(f"✓ 去除离群点后: {len(pcd.points)} 个点")
        
        if save:
            output_file = self.output_dir / f"frame_{frame_idx:06d}.ply"
            o3d.io.write_point_cloud(str(output_file), pcd)
            print(f"✓ 点云已保存: {output_file}")
        
        return pcd
    
    def reconstruct_multi_frame(self, frame_indices: List[int] = None, 
                               max_frames: int = 50, stride: int = 10):
        """
        重建多帧并融合（假设相机静止或已对齐）
        
        Args:
            frame_indices: 指定要重建的帧索引列表
            max_frames: 最大处理帧数
            stride: 帧间隔（每隔几帧取一帧）
        """
        print(f"\n=== 重建多帧融合点云 ===")
        
        # 确定要处理的帧
        if frame_indices is None:
            rgb_files = sorted(self.rgb_dir.glob("*.png"))
            num_frames = min(len(rgb_files), max_frames * stride)
            frame_indices = list(range(0, num_frames, stride))
        
        print(f"将处理 {len(frame_indices)} 帧")
        
        # 融合所有帧
        combined_pcd = o3d.geometry.PointCloud()
        
        for i, frame_idx in enumerate(frame_indices):
            pcd = self.rgbd_to_pointcloud(frame_idx)
            if pcd is None:
                continue
            
            combined_pcd += pcd
            
            if (i + 1) % 10 == 0:
                print(f"  已处理 {i+1}/{len(frame_indices)} 帧")
        
        print(f"✓ 融合完成: {len(combined_pcd.points)} 个点")
        
        # 下采样和去噪
        print("正在下采样...")
        combined_pcd = combined_pcd.voxel_down_sample(voxel_size=0.005)  # 5mm体素
        print(f"✓ 下采样后: {len(combined_pcd.points)} 个点")
        
        print("正在去除离群点...")
        combined_pcd, _ = combined_pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
        print(f"✓ 去噪后: {len(combined_pcd.points)} 个点")
        
        # 保存融合点云
        output_file = self.output_dir / "combined_pointcloud.ply"
        o3d.io.write_point_cloud(str(output_file), combined_pcd)
        print(f"✓ 融合点云已保存: {output_file}")
        
        return combined_pcd
    
    def detect_table_plane(self, pcd: o3d.geometry.PointCloud, 
                          distance_threshold: float = 0.01,
                          ransac_n: int = 3,
                          num_iterations: int = 1000) -> Tuple[np.ndarray, List[int]]:
        """
        使用RANSAC检测桌面平面
        
        Args:
            pcd: 输入点云
            distance_threshold: RANSAC距离阈值
            ransac_n: RANSAC采样点数
            num_iterations: RANSAC迭代次数
            
        Returns:
            plane_model: 平面方程参数 [a, b, c, d]
            inliers: 平面上的点索引
        """
        print("\n=== 检测桌面平面 ===")
        
        plane_model, inliers = pcd.segment_plane(
            distance_threshold=distance_threshold,
            ransac_n=ransac_n,
            num_iterations=num_iterations
        )
        
        [a, b, c, d] = plane_model
        print(f"✓ 检测到平面方程: {a:.3f}x + {b:.3f}y + {c:.3f}z + {d:.3f} = 0")
        print(f"  平面上有 {len(inliers)} 个点 ({len(inliers)/len(pcd.points)*100:.1f}%)")
        
        # 分离平面和物体点云
        table_pcd = pcd.select_by_index(inliers)
        objects_pcd = pcd.select_by_index(inliers, invert=True)
        
        # 给平面和物体上色
        table_pcd.paint_uniform_color([0.7, 0.7, 0.7])  # 灰色桌面
        
        # 保存
        o3d.io.write_point_cloud(str(self.output_dir / "table_plane.ply"), table_pcd)
        o3d.io.write_point_cloud(str(self.output_dir / "objects_above_table.ply"), objects_pcd)
        
        print(f"✓ 桌面点云保存: table_plane.ply ({len(inliers)} 点)")
        print(f"✓ 物体点云保存: objects_above_table.ply ({len(objects_pcd.points)} 点)")
        
        return plane_model, inliers, table_pcd, objects_pcd
    
    def segment_objects(self, objects_pcd: o3d.geometry.PointCloud,
                       eps: float = 0.02, min_points: int = 100) -> List[o3d.geometry.PointCloud]:
        """
        使用DBSCAN聚类分割物体
        
        Args:
            objects_pcd: 物体点云（已移除桌面）
            eps: DBSCAN邻域半径
            min_points: 最小聚类点数
            
        Returns:
            segmented_objects: 分割后的物体点云列表
        """
        print("\n=== 分割物体 ===")
        
        # DBSCAN聚类
        labels = np.array(objects_pcd.cluster_dbscan(
            eps=eps,
            min_points=min_points,
            print_progress=False
        ))
        
        max_label = labels.max()
        print(f"✓ 检测到 {max_label + 1} 个物体聚类")
        
        # 为每个聚类分配颜色
        colors = plt.cm.tab20(np.linspace(0, 1, max_label + 1))[:, :3]
        
        segmented_objects = []
        object_info = []
        
        for label_id in range(max_label + 1):
            indices = np.where(labels == label_id)[0]
            if len(indices) < min_points:
                continue
            
            obj_pcd = objects_pcd.select_by_index(indices.tolist())
            obj_pcd.paint_uniform_color(colors[label_id])
            segmented_objects.append(obj_pcd)
            
            # 计算物体边界框和中心
            bbox = obj_pcd.get_axis_aligned_bounding_box()
            center = bbox.get_center()
            extent = bbox.get_extent()
            
            object_info.append({
                'id': label_id,
                'num_points': len(indices),
                'center': center.tolist(),
                'extent': extent.tolist(),
                'bbox_min': bbox.get_min_bound().tolist(),
                'bbox_max': bbox.get_max_bound().tolist()
            })
            
            print(f"  物体 {label_id}: {len(indices)} 点, 中心={center}, 尺寸={extent}")
            
            # 保存单个物体
            o3d.io.write_point_cloud(
                str(self.output_dir / f"object_{label_id:02d}.ply"), 
                obj_pcd
            )
        
        # 保存物体信息
        info_file = self.output_dir / "objects_info.json"
        with open(info_file, 'w') as f:
            json.dump(object_info, f, indent=2)
        
        print(f"✓ 物体信息已保存: {info_file}")
        
        # 保存所有物体的彩色点云
        all_objects = o3d.geometry.PointCloud()
        for obj in segmented_objects:
            all_objects += obj
        o3d.io.write_point_cloud(
            str(self.output_dir / "all_objects_colored.ply"),
            all_objects
        )
        
        return segmented_objects, object_info
    
    def visualize_scene(self, pcd: o3d.geometry.PointCloud, 
                       table_pcd: o3d.geometry.PointCloud = None,
                       objects: List[o3d.geometry.PointCloud] = None):
        """
        可视化场景
        
        Args:
            pcd: 完整点云
            table_pcd: 桌面点云
            objects: 分割后的物体列表
        """
        print("\n=== 可视化场景 ===")
        print("按 Q 或 ESC 关闭窗口")
        
        geometries = []
        
        if table_pcd is not None:
            geometries.append(table_pcd)
        
        if objects is not None:
            geometries.extend(objects)
        
        if not geometries:
            geometries = [pcd]
        
        # 添加坐标系
        coordinate_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(
            size=0.1, origin=[0, 0, 0]
        )
        geometries.append(coordinate_frame)
        
        o3d.visualization.draw_geometries(
            geometries,
            window_name="RGBD Reconstruction - Desktop Scene",
            width=1280,
            height=720,
            left=50,
            top=50
        )
    
    def full_pipeline(self, frame_indices: List[int] = None,
                     max_frames: int = 50, stride: int = 10,
                     visualize: bool = True):
        """
        完整重建流程
        
        Args:
            frame_indices: 指定帧索引
            max_frames: 最大帧数
            stride: 帧间隔
            visualize: 是否可视化
        """
        print("=" * 60)
        print("RGBD 桌面物体三维重建 - 完整流程")
        print("=" * 60)
        
        # 1. 多帧融合
        combined_pcd = self.reconstruct_multi_frame(
            frame_indices=frame_indices,
            max_frames=max_frames,
            stride=stride
        )
        
        # 2. 检测桌面
        plane_model, inliers, table_pcd, objects_pcd = self.detect_table_plane(combined_pcd)
        
        # 3. 分割物体
        segmented_objects, object_info = self.segment_objects(objects_pcd)
        
        # 4. 生成报告
        self.generate_report(plane_model, len(inliers), object_info)
        
        # 5. 可视化
        if visualize:
            self.visualize_scene(combined_pcd, table_pcd, segmented_objects)
        
        print("\n" + "=" * 60)
        print("✓ 重建完成！")
        print(f"✓ 输出目录: {self.output_dir}")
        print("=" * 60)
        
        return combined_pcd, table_pcd, segmented_objects, object_info
    
    def generate_report(self, plane_model, num_table_points, object_info):
        """生成重建报告"""
        report_file = self.output_dir / "reconstruction_report.md"
        
        with open(report_file, 'w') as f:
            f.write("# RGBD 桌面物体重建报告\n\n")
            f.write(f"数据目录: `{self.data_dir}`\n\n")
            
            f.write("## 相机参数\n\n")
            f.write(f"- RGB相机: {self.rgb_width}x{self.rgb_height}\n")
            f.write(f"  - fx={self.rgb_fx:.2f}, fy={self.rgb_fy:.2f}\n")
            f.write(f"  - cx={self.rgb_cx:.2f}, cy={self.rgb_cy:.2f}\n")
            f.write(f"- 深度相机: {self.depth_width}x{self.depth_height}\n\n")
            
            f.write("## 桌面检测\n\n")
            [a, b, c, d] = plane_model
            f.write(f"- 平面方程: `{a:.4f}x + {b:.4f}y + {c:.4f}z + {d:.4f} = 0`\n")
            f.write(f"- 桌面点数: {num_table_points}\n\n")
            
            f.write("## 检测到的物体\n\n")
            f.write(f"共检测到 **{len(object_info)}** 个物体\n\n")
            
            for obj in object_info:
                f.write(f"### 物体 {obj['id']}\n\n")
                f.write(f"- 点数: {obj['num_points']}\n")
                f.write(f"- 中心坐标: ({obj['center'][0]:.3f}, {obj['center'][1]:.3f}, {obj['center'][2]:.3f}) 米\n")
                f.write(f"- 尺寸: {obj['extent'][0]*100:.1f} × {obj['extent'][1]*100:.1f} × {obj['extent'][2]*100:.1f} cm\n")
                f.write(f"- 边界框:\n")
                f.write(f"  - 最小点: ({obj['bbox_min'][0]:.3f}, {obj['bbox_min'][1]:.3f}, {obj['bbox_min'][2]:.3f})\n")
                f.write(f"  - 最大点: ({obj['bbox_max'][0]:.3f}, {obj['bbox_max'][1]:.3f}, {obj['bbox_max'][2]:.3f})\n")
                f.write(f"- 文件: `object_{obj['id']:02d}.ply`\n\n")
            
            f.write("## 输出文件\n\n")
            f.write("- `combined_pointcloud.ply` - 完整场景点云\n")
            f.write("- `table_plane.ply` - 桌面平面点云\n")
            f.write("- `objects_above_table.ply` - 桌面上所有物体点云\n")
            f.write("- `all_objects_colored.ply` - 彩色分割的物体点云\n")
            f.write("- `object_XX.ply` - 单个物体点云\n")
            f.write("- `objects_info.json` - 物体详细信息（JSON格式）\n")
        
        print(f"✓ 报告已生成: {report_file}")


def main():
    parser = argparse.ArgumentParser(description="RGBD桌面物体三维重建")
    parser.add_argument("data_dir", type=str, help="RGBD数据目录（包含rgb/和depth/子目录）")
    parser.add_argument("--mode", type=str, default="full", 
                       choices=["single", "multi", "full"],
                       help="运行模式: single(单帧), multi(多帧融合), full(完整流程)")
    parser.add_argument("--frame", type=int, default=0, help="单帧模式下的帧索引")
    parser.add_argument("--max-frames", type=int, default=50, help="最大处理帧数")
    parser.add_argument("--stride", type=int, default=10, help="帧间隔")
    parser.add_argument("--no-viz", action="store_true", help="不显示可视化窗口")
    
    args = parser.parse_args()
    
    # 创建重建器
    reconstructor = RGBDReconstructor(args.data_dir)
    
    # 根据模式运行
    if args.mode == "single":
        pcd = reconstructor.reconstruct_single_frame(args.frame, save=True)
        if pcd and not args.no_viz:
            o3d.visualization.draw_geometries([pcd])
    
    elif args.mode == "multi":
        pcd = reconstructor.reconstruct_multi_frame(
            max_frames=args.max_frames,
            stride=args.stride
        )
        if not args.no_viz:
            o3d.visualization.draw_geometries([pcd])
    
    elif args.mode == "full":
        reconstructor.full_pipeline(
            max_frames=args.max_frames,
            stride=args.stride,
            visualize=not args.no_viz
        )


if __name__ == "__main__":
    # 需要matplotlib用于物体着色
    import matplotlib.pyplot as plt
    main()
