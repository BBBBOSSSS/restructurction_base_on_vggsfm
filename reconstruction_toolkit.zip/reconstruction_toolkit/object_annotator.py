#!/usr/bin/env python3
"""
交互式工具：在VGGSfM重建的RGB图像上标注物体，获取其三维坐标
"""
import os
import sys
import json
import numpy as np
import cv2
from pathlib import Path
from typing import List, Tuple


class ObjectAnnotator:
    """物体三维坐标标注工具"""
    
    def __init__(self, sfm_output_dir: str, camera_info_file: str):
        """
        初始化标注工具
        Args:
            sfm_output_dir: VGGSfM sparse输出目录
            camera_info_file: 相机参数JSON文件
        """
        self.sfm_dir = Path(sfm_output_dir)
        self.images_dir = (Path(sfm_output_dir).parent / "images") if "sparse" in sfm_output_dir else None
        
        # 加载相机参数
        with open(camera_info_file, 'r') as f:
            info = json.load(f)
        
        cam_info = info.get("camera_info", {})
        self.fx = cam_info.get("fx", 618.0)
        self.fy = cam_info.get("fy", 618.0)
        self.cx = cam_info.get("cx", 320.0)
        self.cy = cam_info.get("cy", 240.0)
        self.K = np.array([
            [self.fx, 0, self.cx],
            [0, self.fy, self.cy],
            [0, 0, 1]
        ])
        
        self.annotations = {}
        self.current_frame_idx = 0
        self.mouse_pos = None
        self.selected_points = []
    
    def _mouse_callback(self, event, x, y, flags, param):
        """鼠标回调函数"""
        self.mouse_pos = (x, y)
        
        if event == cv2.EVENT_LBUTTONDOWN:
            print(f"  点击: ({x}, {y})")
            self.selected_points.append((x, y))
            
            # 在画布上绘制
            cv2.circle(param, (x, y), 5, (0, 0, 255), -1)
            cv2.circle(param, (x, y), 10, (0, 255, 0), 1)
    
    def run_interactive(self, depth_dir=None, z_fixed=0.5):
        """
        交互式标注模式
        Args:
            depth_dir: 深度图像目录（可选）
            z_fixed: 如果没有深度图，使用的固定Z值（米）
        """
        print("="*60)
        print("物体三维坐标标注工具")
        print("="*60)
        print("")
        print("操作说明:")
        print("  左键点击: 标注物体位置")
        print("  Space: 保存当前帧的标注")
        print("  N: 下一帧")
        print("  P: 上一帧")
        print("  C: 清除当前帧的标注")
        print("  Q: 退出")
        print("")
        
        # 获取图像列表
        if not self.images_dir or not self.images_dir.exists():
            # 从sparse目录找images
            parent = self.sfm_dir.parent if "sparse" in str(self.sfm_dir) else self.sfm_dir
            for potential_img_dir in [parent / "images", parent.parent / "rgb", parent.parent]:
                if (potential_img_dir / "images").exists():
                    self.images_dir = potential_img_dir / "images"
                    break
        
        if not self.images_dir or not self.images_dir.exists():
            print(f"ERROR: 无法找到图像目录")
            return
        
        img_files = sorted(self.images_dir.glob("*.png"))
        if not img_files:
            img_files = sorted(self.images_dir.glob("*.jpg"))
        
        if not img_files:
            print(f"ERROR: 在 {self.images_dir} 中未找到图像")
            return
        
        print(f"找到 {len(img_files)} 张图像\n")
        
        while self.current_frame_idx < len(img_files):
            img_file = img_files[self.current_frame_idx]
            img = cv2.imread(str(img_file))
            
            if img is None:
                print(f"无法读取: {img_file}")
                self.current_frame_idx += 1
                continue
            
            # 复制用于显示
            display_img = img.copy()
            
            # 显示已有的标注
            frame_key = f"frame_{self.current_frame_idx}"
            if frame_key in self.annotations:
                for i, (x, y, obj_id, desc) in enumerate(self.annotations[frame_key]):
                    cv2.circle(display_img, (x, y), 8, (0, 255, 0), -1)
                    cv2.putText(display_img, str(i), (x+10, y-10), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            
            # 显示窗口
            cv2.namedWindow('Image', cv2.WINDOW_NORMAL)
            cv2.resizeWindow('Image', 1024, 768)
            cv2.setMouseCallback('Image', self._mouse_callback, display_img)
            
            print(f"\n帧 {self.current_frame_idx + 1}/{len(img_files)}: {img_file.name}")
            print("点击标注物体，按Space保存，N下一帧，Q退出")
            
            self.selected_points = []
            
            while True:
                cv2.imshow('Image', display_img)
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):  # 退出
                    print("退出标注...")
                    cv2.destroyAllWindows()
                    return
                
                elif key == ord(' '):  # 保存当前帧
                    if self.selected_points:
                        frame_key = f"frame_{self.current_frame_idx}"
                        self.annotations[frame_key] = []
                        
                        for i, (x, y) in enumerate(self.selected_points):
                            # 计算三维坐标
                            x_norm = (x - self.cx) / self.fx
                            y_norm = (y - self.cy) / self.fy
                            
                            # 使用固定的深度
                            z = z_fixed
                            x_3d = x_norm * z
                            y_3d = y_norm * z
                            
                            self.annotations[frame_key].append({
                                "pixel": [float(x), float(y)],
                                "camera_coords": [float(x_3d), float(y_3d), float(z)],
                                "object_id": i,
                                "description": f"Object_{i}"
                            })
                            
                            print(f"  物体{i}: 像素({x},{y}) -> 相机坐标({x_3d:.3f}, {y_3d:.3f}, {z})")
                        
                        print(f"✓ 保存 {len(self.selected_points)} 个物体的标注\n")
                    break
                
                elif key == ord('n'):  # 下一帧
                    self.current_frame_idx += 1
                    print("下一帧...\n")
                    break
                
                elif key == ord('p'):  # 上一帧
                    if self.current_frame_idx > 0:
                        self.current_frame_idx -= 1
                        print("上一帧...\n")
                    break
                
                elif key == ord('c'):  # 清除
                    self.selected_points = []
                    display_img = img.copy()
                    print("已清除当前标注\n")
        
        cv2.destroyAllWindows()
        self._save_annotations()
    
    def _save_annotations(self):
        """保存标注结果"""
        output_file = Path("object_annotations.json")
        with open(output_file, 'w') as f:
            json.dump(self.annotations, f, indent=2)
        
        print(f"\n✓ 标注已保存到: {output_file}")
        print(f"  总共标注了 {len(self.annotations)} 帧，{sum(len(v) for v in self.annotations.values())} 个物体")


def main():
    if len(sys.argv) < 3:
        print("用法: python3 object_annotator.py <sfm_output_dir> <camera_info.json> [depth_dir]")
        print("")
        print("示例:")
        print("  python3 object_annotator.py /path/to/sparse /path/to/info/metadata.json")
        sys.exit(1)
    
    sfm_dir = sys.argv[1]
    info_file = sys.argv[2]
    depth_dir = sys.argv[3] if len(sys.argv) > 3 else None
    
    if not os.path.exists(info_file):
        print(f"ERROR: 相机参数文件不存在: {info_file}")
        sys.exit(1)
    
    # 创建标注工具
    annotator = ObjectAnnotator(sfm_dir, info_file)
    
    # 运行交互式标注
    annotator.run_interactive(depth_dir)


if __name__ == "__main__":
    main()
