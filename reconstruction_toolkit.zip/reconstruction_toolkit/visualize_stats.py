#!/usr/bin/env python3
"""
3D重建效果可视化 - 生成统计图表
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import pycolmap
from pathlib import Path
import sys


def visualize_reconstruction(rec_dir, output_dir=None):
    """生成重建效果的统计图表"""
    
    rec = pycolmap.Reconstruction(str(rec_dir))
    
    if output_dir is None:
        output_dir = Path(rec_dir).parent
    else:
        output_dir = Path(output_dir)
    
    # 创建2x2的子图
    fig = plt.figure(figsize=(16, 12))
    fig.suptitle('COLMAP 3D重建效果分析', fontsize=16, fontweight='bold')
    
    # ========== 图1: 3D点云 ==========
    ax1 = fig.add_subplot(2, 3, 1, projection='3d')
    
    points = np.array([p.xyz for p in rec.points3D.values()])
    colors = np.array([p.color for p in rec.points3D.values()]) / 255.0
    
    # 标准化坐标用于显示
    points_norm = points - points.mean(axis=0)
    points_norm = points_norm / (np.abs(points_norm).max() + 1e-6)
    
    ax1.scatter(points_norm[:, 0], points_norm[:, 1], points_norm[:, 2], 
                c=colors, s=10, alpha=0.6)
    ax1.set_xlabel('X')
    ax1.set_ylabel('Y')
    ax1.set_zlabel('Z')
    ax1.set_title(f'3D Point Cloud ({len(points)} points)')
    
    # ========== 图2: 重投影误差分布 ==========
    ax2 = fig.add_subplot(2, 3, 2)
    
    errors = np.array([p.error for p in rec.points3D.values()])
    
    ax2.hist(errors, bins=50, color='skyblue', edgecolor='black', alpha=0.7)
    ax2.axvline(errors.mean(), color='red', linestyle='--', linewidth=2, label=f'Mean: {errors.mean():.4f}')
    ax2.axvline(np.median(errors), color='green', linestyle='--', linewidth=2, label=f'Median: {np.median(errors):.4f}')
    ax2.set_xlabel('Reprojection Error (pixels)')
    ax2.set_ylabel('Frequency')
    ax2.set_title('Reprojection Error Distribution')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # ========== 图3: 追踪长度分布 ==========
    ax3 = fig.add_subplot(2, 3, 3)
    
    track_lengths = np.array([len(p.track.elements) for p in rec.points3D.values()])
    
    ax3.hist(track_lengths, bins=range(2, max(track_lengths)+2), color='lightcoral', 
             edgecolor='black', alpha=0.7)
    ax3.axvline(track_lengths.mean(), color='red', linestyle='--', linewidth=2, 
                label=f'Mean: {track_lengths.mean():.2f}')
    ax3.set_xlabel('Track Length (# of images)')
    ax3.set_ylabel('Frequency')
    ax3.set_title('3D Point Track Length Distribution')
    ax3.legend()
    ax3.grid(True, alpha=0.3)
    
    # ========== 图4: 点云范围统计 ==========
    ax4 = fig.add_subplot(2, 3, 4)
    ax4.axis('off')
    
    stats_text = f"""
    ==================== Basic Stats ====================
    Cameras:              {rec.num_cameras()}
    Total Images:         {rec.num_images()}
    Registered Images:    {rec.num_reg_images()} ({100*rec.num_reg_images()/rec.num_images():.1f}%)
    3D Points:            {rec.num_points3D()}
    
    =================== Point Cloud Range ================
    X: [{points[:,0].min():.3f}, {points[:,0].max():.3f}]  (range: {points[:,0].max()-points[:,0].min():.3f})
    Y: [{points[:,1].min():.3f}, {points[:,1].max():.3f}]  (range: {points[:,1].max()-points[:,1].min():.3f})
    Z: [{points[:,2].min():.3f}, {points[:,2].max():.3f}]  (range: {points[:,2].max()-points[:,2].min():.3f})
    
    =================== Error Statistics =================
    Mean Reproj Error:    {errors.mean():.4f} px
    Median:               {np.median(errors):.4f} px
    Std Dev:              {errors.std():.4f} px
    Max Error:            {errors.max():.4f} px
    Min Error:            {errors.min():.4f} px
    """
    
    ax4.text(0.1, 0.5, stats_text, transform=ax4.transAxes, 
             fontfamily='monospace', fontsize=10, verticalalignment='center',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    # ========== 图5: 相机位置分布 ==========
    ax5 = fig.add_subplot(2, 3, 5, projection='3d')
    
    # Simplified version - show 3D points only
    ax5.scatter(points[:, 0], points[:, 1], points[:, 2],
                c=colors, s=20, alpha=0.6, label='3D Points')
    ax5.set_xlabel('X')
    ax5.set_ylabel('Y')
    ax5.set_zlabel('Z')
    ax5.set_title('3D Point Cloud Distribution')
    ax5.legend()
    
    # ========== 图6: 重建质量评分 ==========
    ax6 = fig.add_subplot(2, 3, 6)
    ax6.axis('off')
    
    # Calculate quality metrics
    registration_ratio = 100 * rec.num_reg_images() / rec.num_images()
    avg_track_length = track_lengths.mean()
    avg_error = errors.mean()
    density_score = min(100, rec.num_points3D() / rec.num_images() * 10)
    
    # Overall score (0-100)
    overall_score = (
        registration_ratio * 0.3 +        # 30% registration rate
        min(100, avg_track_length * 10) * 0.2 +  # 20% track length
        max(0, 100 - avg_error * 20) * 0.3 +     # 30% low error
        density_score * 0.2                       # 20% point density
    )
    
    quality_text = f"""
    =============== Reconstruction Quality ===============
    
    Registration Rate:    {registration_ratio:.1f}% {'✓' if registration_ratio>=90 else '⚠'}
    Avg Track Length:     {avg_track_length:.2f}  {'✓' if avg_track_length>=5 else '⚠'}
    Avg Reproj Error:     {avg_error:.4f} px  {'✓' if avg_error<1.0 else '⚠'}
    Point Density:        {density_score:.1f}%  {'✓' if density_score>=50 else '⚠'}
    
    ================= Overall Score ==================
    
                    {overall_score:.1f} / 100
    """
    
    color_map = {
        range(0, 60): 'red',
        range(60, 75): 'orange', 
        range(75, 90): 'yellow',
        range(90, 101): 'green'
    }
    
    if overall_score >= 90:
        quality_color = 'lightgreen'
        quality_desc = "Excellent ⭐⭐⭐"
    elif overall_score >= 75:
        quality_color = 'lightyellow'
        quality_desc = "Good ⭐⭐"
    elif overall_score >= 60:
        quality_color = 'lightsalmon'
        quality_desc = "Fair ⭐"
    else:
        quality_color = 'lightcoral'
        quality_desc = "Poor"
    
    quality_text += f"\nRating: {quality_desc}"
    
    ax6.text(0.1, 0.5, quality_text, transform=ax6.transAxes,
             fontfamily='monospace', fontsize=11, verticalalignment='center',
             bbox=dict(boxstyle='round', facecolor=quality_color, alpha=0.7))
    
    plt.tight_layout()
    
    # 保存图表
    output_file = output_dir / "reconstruction_analysis.png"
    plt.savefig(str(output_file), dpi=150, bbox_inches='tight')
    print(f"✓ 已保存分析图表: {output_file}")
    
    return output_file


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python visualize_stats.py <重建目录>")
        sys.exit(1)
    
    rec_dir = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None
    
    visualize_reconstruction(rec_dir, output_dir)
    print("\n✓ 可视化完成!")
