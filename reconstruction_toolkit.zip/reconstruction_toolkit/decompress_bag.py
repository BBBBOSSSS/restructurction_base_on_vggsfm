#!/usr/bin/env python3
"""
解压lz4压缩的ROS bag文件
"""
import os
import sys
import rosbag
from pathlib import Path

def decompress_bag(bag_path, output_path):
    """解压lz4压缩的bag文件"""
    print(f"打开compressed bag: {bag_path}")
    
    try:
        # 打开原始bag文件
        bag_in = rosbag.Bag(bag_path, 'r')
    except rosbag.bag.ROSBagException as e:
        if 'lz4' in str(e).lower():
            print("✗ 无法读取lz4压缩的bag文件")
            print("需要ROS环境或等待官方支持")
            return False
        raise
    
    print(f"创建uncompressed bag: {output_path}")
    
    try:
        # 创建新的未压缩bag文件
        bag_out = rosbag.Bag(output_path, 'w', compression=rosbag.bag.Compression.NONE)
        
        msg_count = 0
        for topic, msg, t in bag_in.read_messages():
            bag_out.write(topic, msg, t)
            msg_count += 1
            if msg_count % 100 == 0:
                print(f"  已处理 {msg_count} 条消息...")
        
        bag_out.close()
        print(f"✓ 解压完成! 共 {msg_count} 条消息")
        return True
        
    except Exception as e:
        print(f"✗ 解压失败: {e}")
        return False
    finally:
        bag_in.close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 decompress_bag.py <compressed.bag> [output.bag]")
        sys.exit(1)
    
    bag_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else bag_path.replace('.bag', '_uncompressed.bag')
    
    if not os.path.exists(bag_path):
        print(f"ERROR: 文件不存在: {bag_path}")
        sys.exit(1)
    
    success = decompress_bag(bag_path, output_path)
    sys.exit(0 if success else 1)
