#!/usr/bin/env python3
"""
使用正确的AprilTag坐标系变换所有物体坐标
基于fix_axes_final.py生成的正确可视化
"""
import numpy as np
import open3d as o3d
import json
import glob
from pathlib import Path

# 加载正确的AprilTag位姿
pose_file = 'output/20260205_163837/rgbd_reconstruction/apriltag_frame/apriltag_pose_correct.json'
with open(pose_file, 'r') as f:
    pose_data = json.load(f)

pose_t = np.array(pose_data['tvec'])
pose_R_original = np.array(pose_data['R_original_apriltags'])

print("AprilTag位姿信息：")
print(f"  标签ID: {pose_data['tag_id']}")
print(f"  标签尺寸: {pose_data['tag_size_m']*100:.1f}cm")
print(f"  距离相机: {pose_data['distance_m']*100:.1f}cm")
print(f"  检测置信度: {pose_data['decision_margin']:.1f}")
print()

# 正确的坐标轴映射（基于fix_axes_final.py的config2）：
# X_desired（向右）= -Z_dt_apriltags
# Y_desired（向下）= X_dt_apriltags  
# Z_desired（向外）= Y_dt_apriltags

# 构建新的旋转矩阵
R_tag_to_cam = np.column_stack([
    -pose_R_original[:, 2],  # X轴 = -原始Z轴
    pose_R_original[:, 0],   # Y轴 = 原始X轴
    pose_R_original[:, 1]    # Z轴 = 原始Y轴
])

print("坐标系变换矩阵：")
print("  X（右）= -dt_Z")
print("  Y（下）= dt_X")
print("  Z（出）= dt_Y")
print()

# 相机坐标系到标签坐标系的变换
T_cam_to_tag = np.eye(4)
T_cam_to_tag[:3, :3] = R_tag_to_cam.T  # 旋转：相机→标签需要转置
T_cam_to_tag[:3, 3] = -R_tag_to_cam.T @ pose_t  # 平移

# 加载相机坐标系中的物体信息
objects_cam_file = 'output/20260205_163837/rgbd_reconstruction/objects_info.json'
with open(objects_cam_file, 'r') as f:
    objects_cam = json.load(f)

# 变换物体中心坐标
objects_tag = []
for obj_cam in objects_cam:
    obj_id = obj_cam['id']
    center_cam = np.array(obj_cam['center'])
    center_cam_homo = np.append(center_cam, 1)
    center_tag_homo = T_cam_to_tag @ center_cam_homo
    center_tag = center_tag_homo[:3]
    
    distance = np.linalg.norm(center_tag)
    
    obj_tag = {
        'object_id': obj_id,
        'center_3d': center_tag.tolist(),
        'distance_from_tag': float(distance),
        'extent': obj_cam['extent'],
        'num_points': obj_cam['num_points'],
        'center_3d_camera_frame': center_cam.tolist(),
        'bbox_min': obj_cam['bbox_min'],
        'bbox_max': obj_cam['bbox_max']
    }
    objects_tag.append(obj_tag)
    
    print(f"物体 {obj_id}:")
    print(f"  标签坐标系: X={center_tag[0]*100:6.2f}cm, Y={center_tag[1]*100:6.2f}cm, Z={center_tag[2]*100:6.2f}cm")
    print(f"  距标签中心: {distance*100:.1f}cm")
    print(f"  尺寸: {obj_cam['extent'][0]*100:.1f} × {obj_cam['extent'][1]*100:.1f} × {obj_cam['extent'][2]*100:.1f} cm")
    print(f"  点数: {obj_cam['num_points']}")
    print()

# 保存结果
output_file = 'output/20260205_163837/rgbd_reconstruction/objects_info_apriltag.json'
result = {
    'apriltag_reference': {
        'tag_id': pose_data['tag_id'],
        'tag_family': pose_data['tag_family'],
        'tag_size_m': pose_data['tag_size_m'],
        'frame': pose_data['frame'],
        'coordinate_system': {
            'origin': 'AprilTag center',
            'X': 'right along tag edge (red)',
            'Y': 'down along tag edge (green)',
            'Z': 'out of tag surface toward camera (blue)',
            'unit': 'meters'
        }
    },
    'objects': objects_tag
}

with open(output_file, 'w') as f:
    json.dump(result, f, indent=2)

print(f"✓ 已保存: {output_file}")
print()

# 变换点云
print("变换点云到标签坐标系...")
pcd_files = glob.glob('output/20260205_163837/rgbd_reconstruction/object_*.ply')

for pcd_file in sorted(pcd_files):
    pcd = o3d.io.read_point_cloud(pcd_file)
    pcd.transform(T_cam_to_tag)
    
    # 保存到新文件
    basename = Path(pcd_file).stem
    out_file = f'output/20260205_163837/rgbd_reconstruction/{basename}_apriltag.ply'
    o3d.io.write_point_cloud(out_file, pcd)
    print(f"  ✓ {basename}_apriltag.ply")

# 变换组合点云和桌面
for name in ['combined_pointcloud', 'table_plane']:
    pcd_file = f'output/20260205_163837/rgbd_reconstruction/{name}.ply'
    if Path(pcd_file).exists():
        pcd = o3d.io.read_point_cloud(pcd_file)
        pcd.transform(T_cam_to_tag)
        out_file = f'output/20260205_163837/rgbd_reconstruction/{name}_apriltag.ply'
        o3d.io.write_point_cloud(out_file, pcd)
        print(f"  ✓ {name}_apriltag.ply")

print("\n✓ 所有坐标已变换到AprilTag坐标系")
print("  坐标系定义: X向右（沿标签边缘）, Y向下（沿标签边缘）, Z向外（垂直标签平面）")
print(f"  参考图像: apriltag_correct.jpg")
