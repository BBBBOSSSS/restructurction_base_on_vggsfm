#!/usr/bin/env python3
"""
AprilTag检测、三维姿态估计和物体坐标标定
"""
import os
import sys
import json
import numpy as np
import cv2
from pathlib import Path
from dataclasses import dataclass, asdict
import pickle

try:
    import pupil_apriltags
    APRILTAGS_AVAILABLE = True
except ImportError:
    APRILTAGS_AVAILABLE = False


@dataclass
class CameraIntrinsics:
    """相机内参"""
    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int
    distortion: list = None


@dataclass
class AprilTagDetection:
    """AprilTag检测结果"""
    tag_id: int
    center: tuple  # (x, y)
    corners: np.ndarray  # 4个角点坐标
    pose_t: np.ndarray  # 3D平移向量
    pose_r: np.ndarray  # 3D旋转矩阵
    frame_idx: int


class AprilTagCalibrator:
    """AprilTag检测和坐标标定"""
    
    def __init__(self, camera_info_file, rgb_dir, depth_dir=None, tag_size=0.05):
        """
        初始化
        Args:
            camera_info_file: 相机参数JSON文件
            rgb_dir: RGB图像目录
            depth_dir: 深度图像目录（可选，用于深度标定）
            tag_size: AprilTag物理尺寸（米）
        """
        self.camera_info = self._load_camera_info(camera_info_file)
        self.rgb_dir = Path(rgb_dir)
        self.depth_dir = Path(depth_dir) if depth_dir else None
        self.tag_size = tag_size
        
        # 初始化AprilTag检测器
        if not APRILTAGS_AVAILABLE:
            raise ImportError("请安装pupil-apriltags: pip install pupil-apriltags")
        
        self.detector = pupil_apriltags.Detector(
            families='tag36h11',
            nthreads=4,
            quad_decimate=1.0,
            quad_blur=0.0,
            refine_edges=True,
            decode_sharpening=0.25,
            debug=False
        )
        
        self.detections = []
        self.calibration_results = {}
    
    def _load_camera_info(self, info_file):
        """加载相机内参"""
        with open(info_file, 'r') as f:
            info = json.load(f)
        
        camera_info = info.get("camera_info", {})
        return CameraIntrinsics(
            fx=camera_info.get("fx", 618.0),
            fy=camera_info.get("fy", 618.0),
            cx=camera_info.get("cx", 320.0),
            cy=camera_info.get("cy", 240.0),
            width=camera_info.get("width", 640),
            height=camera_info.get("height", 480),
            distortion=camera_info.get("distortion", [0]*5)
        )
    
    def detect_in_images(self, frame_indices=None):
        """检测所有RGB图像中的AprilTag"""
        print("检测AprilTag...")
        
        rgb_files = sorted(self.rgb_dir.glob("*_rgb.png"))
        
        for rgb_file in rgb_files:
            # 解析帧索引
            frame_idx = int(rgb_file.stem.split('_')[0])
            
            if frame_indices and frame_idx not in frame_indices:
                continue
            
            # 读取图像
            img = cv2.imread(str(rgb_file))
            if img is None:
                print(f"  WARNING: 无法读取 {rgb_file}")
                continue
            
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # 检测AprilTag
            tags = self.detector.detect(img_gray)
            
            if tags:
                print(f"  Frame {frame_idx}: 检测到 {len(tags)} 个AprilTag")
                
                for tag in tags:
                    # 计算AprilTag的3D姿态
                    pose_r, pose_t = self._estimate_tag_pose(tag)
                    
                    detection = AprilTagDetection(
                        tag_id=tag.tag_id,
                        center=(tag.center[0], tag.center[1]),
                        corners=tag.corners,
                        pose_t=pose_t,
                        pose_r=pose_r,
                        frame_idx=frame_idx
                    )
                    
                    self.detections.append(detection)
                    print(f"    Tag ID: {tag.tag_id}, 位置: ({tag.center[0]:.1f}, {tag.center[1]:.1f})")
    
    def _estimate_tag_pose(self, tag):
        """估计AprilTag的3D姿态（相对于相机坐标系）"""
        # AprilTag 4个角点（相机标准化坐标系中的图像坐标）
        corners_2d = np.array(tag.corners, dtype=np.float32)
        
        # AprilTag 3D角点（标签坐标系）
        # 假设tag在Z=self.tag_size的平面上
        s = self.tag_size / 2
        corners_3d = np.array([
            [-s, -s, 0],
            [ s, -s, 0],
            [ s,  s, 0],
            [-s,  s, 0]
        ], dtype=np.float32)
        
        # 内参矩阵
        K = np.array([
            [self.camera_info.fx, 0, self.camera_info.cx],
            [0, self.camera_info.fy, self.camera_info.cy],
            [0, 0, 1]
        ], dtype=np.float32)
        
        # PnP求解
        success, rvec, tvec = cv2.solvePnP(
            corners_3d, corners_3d,
            K, np.array(self.camera_info.distortion or [0]*5),
            useExtrinsicGuess=False,
            flags=cv2.SOLVEPNP_EPNP
        )
        
        # 转换旋转向量为旋转矩阵
        pose_r, _ = cv2.Rodrigues(rvec)
        
        return pose_r, tvec
    
    def calibrate_objects(self, apriltag_positions, object_points_image, output_file="calibration.json"):
        """
        标定桌面上相对于AprilTag的物体坐标
        Args:
            apriltag_positions: 字典 {tag_id: 世界坐标系中的3D位置}
            object_points_image: 字典 {frame_id: [(x, y, object_id), ...]}
        """
        print("\n进行物体坐标标定...")
        
        results = {
            "calibrations": {},
            "apriltags": apriltag_positions
        }
        
        # 对每个被检测到AprilTag的帧进行标定
        for detection in self.detections:
            frame_idx = detection.frame_idx
            
            # 获取该帧的物体点
            if frame_idx not in object_points_image:
                continue
            
            points = object_points_image[frame_idx]
            
            # 将图像坐标转换到世界坐标系
            K = np.array([
                [self.camera_info.fx, 0, self.camera_info.cx],
                [0, self.camera_info.fy, self.camera_info.cy],
                [0, 0, 1]
            ])
            
            calib_frame = {
                "tag_id": detection.tag_id,
                "frame_id": frame_idx,
                "objects": []
            }
            
            for x_img, y_img, obj_id in points:
                # 图像坐标转规范化坐标
                x_norm = (x_img - self.camera_info.cx) / self.camera_info.fx
                y_norm = (y_img - self.camera_info.cy) / self.camera_info.fy
                
                # 如果有深度信息，使用深度；否则假设在AprilTag平面上
                if self.depth_dir:
                    depth = self._get_depth_at_pixel(frame_idx, x_img, y_img)
                else:
                    depth = self.tag_size / 2  # 假设在标签上方
                
                # 相机坐标系中的3D坐标
                x_cam = x_norm * depth
                y_cam = y_norm * depth
                z_cam = depth
                
                # 转换到世界坐标系（相对于AprilTag）
                obj_cam = np.array([x_cam, y_cam, z_cam, 1]).reshape(4, 1)
                
                # 若要转到全局坐标系，需要知道AprilTag的世界坐标
                if detection.tag_id in apriltag_positions:
                    tag_world_pos = np.array(apriltag_positions[detection.tag_id])
                    # 创建变换矩阵
                    T = np.eye(4)
                    T[:3, :3] = detection.pose_r
                    T[:3, 3] = detection.pose_t.flatten()
                    
                    obj_world = T @ obj_cam
                    obj_world_pos = obj_world[:3].flatten().tolist()
                else:
                    # 如果没有世界坐标，保存相机坐标
                    obj_world_pos = [x_cam, y_cam, z_cam]
                
                calib_frame["objects"].append({
                    "object_id": obj_id,
                    "image_pos": [float(x_img), float(y_img)],
                    "camera_pos": [float(x_cam), float(y_cam), float(z_cam)],
                    "world_pos": obj_world_pos
                })
            
            results["calibrations"][f"frame_{frame_idx}"] = calib_frame
        
        self.calibration_results = results
        
        # 保存结果
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"✓ 标定完成，结果保存到: {output_file}")
        return results
    
    def _get_depth_at_pixel(self, frame_idx, x, y):
        """获取指定像素的深度值"""
        if not self.depth_dir:
            return None
        
        depth_file = self.depth_dir / f"{frame_idx:06d}_depth.png"
        if not depth_file.exists():
            return None
        
        depth_img = cv2.imread(str(depth_file), cv2.IMREAD_UNCHANGED)
        x, y = int(x), int(y)
        
        if 0 <= x < depth_img.shape[1] and 0 <= y < depth_img.shape[0]:
            return depth_img[y, x] / 1000.0  # 深度值单位转换（mm -> m）
        
        return None
    
    def visualize_detections(self, output_dir="detection_results"):
        """可视化AprilTag检测结果"""
        print("\n生成可视化图像...")
        
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        for detection in self.detections:
            rgb_file = self.rgb_dir / f"{detection.frame_idx:06d}_rgb.png"
            img = cv2.imread(str(rgb_file))
            
            if img is None:
                continue
            
            # 绘制标签边界
            corners = detection.corners.astype(int)
            cv2.polylines(img, [corners], True, (0, 255, 0), 2)
            
            # 绘制标签中心和ID
            center = tuple(map(int, detection.center))
            cv2.circle(img, center, 5, (0, 0, 255), -1)
            cv2.putText(img, f"ID:{detection.tag_id}", 
                       (center[0]+10, center[1]), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            
            # 保存
            output_file = output_path / f"frame_{detection.frame_idx:06d}_tag_{detection.tag_id}.png"
            cv2.imwrite(str(output_file), img)
        
        print(f"✓ 可视化图像保存到: {output_path}")


def main():
    if len(sys.argv) < 3:
        print("用法: python3 apriltag_calibration.py <info.json> <rgb_dir> [depth_dir]")
        sys.exit(1)
    
    info_file = sys.argv[1]
    rgb_dir = sys.argv[2]
    depth_dir = sys.argv[3] if len(sys.argv) > 3 else None
    
    # 创建标定器
    calibrator = AprilTagCalibrator(info_file, rgb_dir, depth_dir)
    
    # 检测AprilTags
    calibrator.detect_in_images()
    
    # 可视化
    calibrator.visualize_detections("apriltag_detections")
    
    # 示例标定（需要用户提供AprilTag的世界坐标和物体点）
    # calibrator.calibrate_objects(
    #     apriltag_positions={0: [0, 0, 0]},
    #     object_points_image={0: [(100, 100, "obj1"), (200, 200, "obj2")]}
    # )


if __name__ == "__main__":
    main()
