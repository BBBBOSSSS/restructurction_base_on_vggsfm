#!/usr/bin/env python3
"""
使用COLMAP进行3D稀疏重建
比VGGSfM更稳定的传统方法
"""

import os
import sys
import shutil
import pycolmap
from pathlib import Path


def run_colmap_reconstruction(image_dir: str, output_dir: str = None):
    """
    使用COLMAP对图片进行3D稀疏重建
    
    Args:
        image_dir: 图片目录路径
        output_dir: 输出目录（默认为image_dir同级的sparse目录）
    """
    image_path = Path(image_dir)
    
    if not image_path.exists():
        print(f"错误: 图片目录不存在: {image_dir}")
        return False
    
    # 设置输出目录
    if output_dir is None:
        output_path = image_path.parent / "sparse"
    else:
        output_path = Path(output_dir)
    
    database_path = image_path.parent / "database.db"
    
    # 清理旧文件
    if database_path.exists():
        os.remove(database_path)
    if output_path.exists():
        shutil.rmtree(output_path)
    output_path.mkdir(parents=True, exist_ok=True)
    
    print(f"图片目录: {image_path}")
    print(f"输出目录: {output_path}")
    print(f"数据库: {database_path}")
    
    # 统计图片数量
    images = list(image_path.glob("*.png")) + list(image_path.glob("*.jpg")) + list(image_path.glob("*.jpeg"))
    print(f"找到 {len(images)} 张图片")
    
    if len(images) < 3:
        print("错误: 需要至少3张图片进行重建")
        return False
    
    # Step 1: 特征提取
    print("\n[1/4] 提取SIFT特征...")
    pycolmap.extract_features(
        database_path=str(database_path),
        image_path=str(image_path),
        camera_mode=pycolmap.CameraMode.AUTO,
        sift_options=pycolmap.SiftExtractionOptions(
            max_num_features=8192,
            first_octave=-1,  # 允许更小的特征
        )
    )
    print("  ✓ 特征提取完成")
    
    # Step 2: 特征匹配
    print("\n[2/4] 特征匹配...")
    pycolmap.match_exhaustive(
        database_path=str(database_path),
        sift_options=pycolmap.SiftMatchingOptions(
            max_ratio=0.8,
            max_distance=0.7,
        )
    )
    print("  ✓ 特征匹配完成")
    
    # Step 3: 增量式SfM重建
    print("\n[3/4] 增量式SfM重建...")
    reconstructions = pycolmap.incremental_mapping(
        database_path=str(database_path),
        image_path=str(image_path),
        output_path=str(output_path),
        options=pycolmap.IncrementalPipelineOptions(
            min_num_matches=15,
            ba_refine_focal_length=True,
            ba_refine_principal_point=False,
            ba_refine_extra_params=True,
        )
    )
    
    if not reconstructions:
        print("  ✗ 重建失败，无法创建有效的3D模型")
        return False
    
    print(f"  ✓ 成功创建 {len(reconstructions)} 个重建模型")
    
    # Step 4: 输出统计信息
    print("\n[4/4] 重建结果统计:")
    for i, rec in enumerate(reconstructions):
        print(f"\n  模型 {i}:")
        print(f"    - 相机数: {rec.num_cameras()}")
        print(f"    - 图片数: {rec.num_images()}")
        print(f"    - 已注册图片: {rec.num_reg_images()}")
        print(f"    - 3D点数: {rec.num_points3D()}")
        
        # 计算重投影误差
        if rec.num_points3D() > 0:
            errors = []
            for point3D_id, point3D in rec.points3D.items():
                errors.append(point3D.error)
            avg_error = sum(errors) / len(errors) if errors else 0
            print(f"    - 平均重投影误差: {avg_error:.4f} px")
    
    # 保存最佳重建结果
    best_rec = max(reconstructions, key=lambda r: r.num_reg_images())
    best_output = output_path / "0"
    best_output.mkdir(exist_ok=True)
    
    best_rec.write(str(best_output))
    print(f"\n✓ 重建完成! 结果已保存到: {best_output}")
    print(f"  - cameras.bin: 相机内参")
    print(f"  - images.bin: 图片位姿")
    print(f"  - points3D.bin: 稀疏点云")
    
    return True


def main():
    if len(sys.argv) < 2:
        print("用法: python colmap_reconstruct.py <图片目录> [输出目录]")
        print("示例: python colmap_reconstruct.py /path/to/images")
        sys.exit(1)
    
    image_dir = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None
    
    success = run_colmap_reconstruction(image_dir, output_dir)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
