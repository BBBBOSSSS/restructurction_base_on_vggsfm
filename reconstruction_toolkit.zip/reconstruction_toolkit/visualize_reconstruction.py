#!/usr/bin/env python3
"""
可视化COLMAP重建结果 - 导出PLY点云和可视化统计
"""

import sys
import numpy as np
import pycolmap
from pathlib import Path


def export_ply(reconstruction_path, output_ply="reconstruction.ply"):
    """导出COLMAP重建为PLY点云格式"""
    
    rec = pycolmap.Reconstruction(str(reconstruction_path))
    
    if rec.num_points3D() == 0:
        print("错误: 没有3D点")
        return False
    
    # 提取3D点坐标和颜色
    points = []
    colors = []
    
    for point3D_id, point3D in rec.points3D.items():
        points.append(point3D.xyz)
        colors.append(point3D.color)
    
    points = np.array(points, dtype=np.float32)
    colors = np.array(colors, dtype=np.uint8)
    
    print(f"导出 {len(points)} 个3D点...")
    
    # 写PLY文件
    with open(output_ply, 'wb') as f:
        # PLY头
        f.write(b"ply\n")
        f.write(b"format binary_little_endian 1.0\n")
        f.write(f"element vertex {len(points)}\n".encode())
        f.write(b"property float x\n")
        f.write(b"property float y\n")
        f.write(b"property float z\n")
        f.write(b"property uchar red\n")
        f.write(b"property uchar green\n")
        f.write(b"property uchar blue\n")
        f.write(b"end_header\n")
        
        # 点数据
        for i in range(len(points)):
            p = points[i]
            c = colors[i]
            f.write(np.array([p[0], p[1], p[2]], dtype=np.float32).tobytes())
            f.write(np.array([c[0], c[1], c[2]], dtype=np.uint8).tobytes())
    
    print(f"✓ 已导出到: {output_ply}")
    return True


def print_reconstruction_info(reconstruction_path):
    """打印重建详细信息"""
    
    rec = pycolmap.Reconstruction(str(reconstruction_path))
    
    print("\n" + "="*60)
    print("COLMAP 3D重建结果")
    print("="*60)
    
    # 基本统计
    print(f"\n基本统计:")
    print(f"  相机数: {rec.num_cameras()}")
    print(f"  图片总数: {rec.num_images()}")
    print(f"  已注册图片: {rec.num_reg_images()} ({100*rec.num_reg_images()/rec.num_images():.1f}%)")
    print(f"  3D点数: {rec.num_points3D()}")
    
    # 相机信息
    print(f"\n相机信息:")
    for cam_id, camera in rec.cameras.items():
        print(f"  Camera {cam_id}:")
        print(f"    - 分辨率: {camera.width} x {camera.height}")
        params = camera.params
        print(f"    - 参数: {params[:4]}")
    
    # 图片信息
    print(f"\n图片信息 (样本):")
    for i, (img_id, image) in enumerate(rec.images.items()):
        if i >= 3:  # 只显示前3张
            break
        print(f"  Image {img_id}: {image.name}")
    
    # 点云统计
    if rec.num_points3D() > 0:
        print(f"\n3D点云统计:")
        
        # 计算点云范围
        points = np.array([p.xyz for p in rec.points3D.values()])
        print(f"  点云范围:")
        print(f"    X: [{points[:,0].min():.3f}, {points[:,0].max():.3f}]")
        print(f"    Y: [{points[:,1].min():.3f}, {points[:,1].max():.3f}]")
        print(f"    Z: [{points[:,2].min():.3f}, {points[:,2].max():.3f}]")
        
        # 计算误差统计
        errors = np.array([p.error for p in rec.points3D.values()])
        print(f"\n  重投影误差统计:")
        print(f"    平均: {errors.mean():.4f} px")
        print(f"    中位数: {np.median(errors):.4f} px")
        print(f"    最大: {errors.max():.4f} px")
        print(f"    最小: {errors.min():.4f} px")
        
        # 计算追踪长度统计
        track_lengths = np.array([len(p.track.elements) for p in rec.points3D.values()])
        print(f"\n  追踪长度统计 (点被多少图片观测):")
        print(f"    平均: {track_lengths.mean():.2f}")
        print(f"    最大: {track_lengths.max()}")
        print(f"    最小: {track_lengths.min()}")
    
    print("\n" + "="*60)


def generate_html_viewer(ply_file="reconstruction.ply", html_file="viewer.html"):
    """生成HTML3D查看器"""
    
    if not Path(ply_file).exists():
        print(f"错误: PLY文件不存在: {ply_file}")
        return False
    
    html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3D重建点云查看器</title>
    <style>
        body {{
            margin: 0;
            overflow: hidden;
            font-family: Arial, sans-serif;
        }}
        canvas {{
            display: block;
        }}
        #info {{
            position: absolute;
            top: 10px;
            left: 10px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 15px;
            border-radius: 5px;
            font-size: 14px;
            z-index: 100;
        }}
        #info p {{
            margin: 5px 0;
        }}
    </style>
</head>
<body>
    <div id="info">
        <h3>3D重建点云查看器</h3>
        <p>鼠标: 左键旋转 | 右键平移 | 滚轮缩放</p>
        <p>按键: R重置视图 | S切换样式 | L切换光照</p>
    </div>
    
    <script async src="https://cdn.jsdelivr.net/npm/three@r128/build/three.min.js"></script>
    <script async src="https://cdn.jsdelivr.net/npm/three@r128/examples/js/controls/OrbitControls.js"></script>
    <script async src="https://cdn.jsdelivr.net/npm/three@r128/examples/js/loaders/PLYLoader.js"></script>
    
    <script>
        let scene, camera, renderer, controls;
        let pointCloud;
        
        function init() {{
            // 场景设置
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x000000);
            
            // 相机
            camera = new THREE.PerspectiveCamera(
                75,
                window.innerWidth / window.innerHeight,
                0.1,
                10000
            );
            camera.position.set(0, 0, 2);
            
            // 渲染器
            renderer = new THREE.WebGLRenderer({{ antialias: true }});
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(window.devicePixelRatio);
            document.body.appendChild(renderer.domElement);
            
            // 控制
            controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.autoRotate = false;
            controls.autoRotateSpeed = 2;
            
            // 加载PLY
            const loader = new THREE.PLYLoader();
            loader.load('{ply_file}', function(geometry) {{
                geometry.computeBoundingBox();
                const center = new THREE.Vector3();
                geometry.boundingBox.getCenter(center);
                geometry.translate(-center.x, -center.y, -center.z);
                
                const size = new THREE.Vector3();
                geometry.boundingBox.getSize(size);
                const maxDim = Math.max(size.x, size.y, size.z);
                const scale = 2.0 / maxDim;
                geometry.scale(scale, scale, scale);
                
                const material = new THREE.PointsMaterial({{
                    size: 0.01,
                    vertexColors: true,
                    sRGBColorSpace: true,
                    fog: true
                }});
                
                pointCloud = new THREE.Points(geometry, material);
                scene.add(pointCloud);
                
                camera.position.z = 3;
                camera.lookAt(0, 0, 0);
                controls.target.set(0, 0, 0);
                controls.update();
                
                render();
            }});
            
            // 光源
            const light = new THREE.AmbientLight(0xffffff, 1.0);
            scene.add(light);
            
            // 响应窗口变化
            window.addEventListener('resize', onWindowResize);
            
            // 键盘控制
            document.addEventListener('keydown', onKeyDown);
        }}
        
        function onWindowResize() {{
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }}
        
        function onKeyDown(event) {{
            if (event.key === 'r' || event.key === 'R') {{
                camera.position.set(0, 0, 3);
                controls.target.set(0, 0, 0);
                controls.update();
            }}
        }}
        
        function render() {{
            requestAnimationFrame(render);
            controls.update();
            renderer.render(scene, camera);
        }}
        
        init();
    </script>
</body>
</html>"""
    
    with open(html_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"✓ 已生成HTML查看器: {html_file}")
    return True


def main():
    if len(sys.argv) < 2:
        print("用法: python visualize_reconstruction.py <重建目录>")
        print("示例: python visualize_reconstruction.py ./sparse/0")
        sys.exit(1)
    
    rec_dir = Path(sys.argv[1])
    output_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else rec_dir.parent
    
    if not rec_dir.exists():
        print(f"错误: 目录不存在: {rec_dir}")
        sys.exit(1)
    
    # 打印信息
    print_reconstruction_info(rec_dir)
    
    # 导出PLY
    ply_file = output_dir / "reconstruction.ply"
    if export_ply(rec_dir, str(ply_file)):
        
        # 生成HTML查看器
        html_file = output_dir / "viewer.html"
        generate_html_viewer(
            ply_file=ply_file.name,
            html_file=str(html_file)
        )
        
        print(f"\n📊 点云统计:")
        import os
        ply_size = os.path.getsize(ply_file) / (1024*1024)
        print(f"  PLY文件大小: {ply_size:.2f} MB")
        print(f"\n🎨 可视化方式:")
        print(f"  1. PLY文件: {ply_file} (CloudCompare, MeshLab等)")
        print(f"  2. 网页查看器: {html_file} (用浏览器打开)")


if __name__ == "__main__":
    main()
