#!/bin/bash
# 完整的三维重建和AprilTag标定工作流

set -e

VGGSFM_DIR="/root/vggsfm"
DATA_DIR="/root/vggsfm/data"
OUTPUT_DIR="/root/vggsfm/reconstruction_output"

mkdir -p "$OUTPUT_DIR"

echo "========================================"
echo "VGGSfM三维重建 + AprilTag标定工作流"
echo "========================================"

# 检查环境
echo ""
echo "检查环境..."
if [ ! -d "$VGGSFM_DIR" ]; then
    echo "ERROR: VGGSfM目录不存在"
    exit 1
fi

if [ ! -d "$DATA_DIR" ]; then
    echo "ERROR: 数据目录不存在"
    exit 1
fi

cd "$VGGSFM_DIR"

# ==========================================
# 第1步: 检查并准备所需工具
# ==========================================
echo ""
echo "[1/5] 准备依赖工具..."

# 检查rosbag
python3 -c "import rosbag" 2>/dev/null || {
    echo "  ⚠ rosbag未安装，尝试安装..."
    pip install rosbag 2>&1 | tail -5 || echo "  Failed to install rosbag (需要ROS环境)"
}

# 检查AprilTag
python3 -c "import pupil_apriltags" 2>/dev/null || {
    echo "  ⚠ pupil-apriltags未安装，尝试安装..."
    pip install pupil-apriltags -q
}

echo "  ✓ 依赖检查完成"

# ==========================================
# 第2步: 从bag文件提取RGB-D
# ==========================================
echo ""
echo "[2/5] 从ROS bag文件提取RGB-D图像..."

for bag_file in "$DATA_DIR"/*.bag; do
    if [ ! -f "$bag_file" ]; then
        echo "  未找到bag文件"
        continue
    fi
    
    bag_name=$(basename "$bag_file" .bag)
    extract_dir="$OUTPUT_DIR/$bag_name"
    
    echo "  处理: $bag_name"
    python3 /root/reconstruction_toolkit/extract_rgbd_from_bag.py "$bag_file" "$extract_dir" || {
        echo "  ⚠ 提取失败 (可能需要ROS环境)"
        continue
    }
    
    # 检查提取结果
    if [ -d "$extract_dir/rgb" ]; then
        rgb_count=$(ls "$extract_dir/rgb"/*.png 2>/dev/null | wc -l)
        echo "  ✓ 提取成功: $rgb_count 帧RGB图像"
    fi
done

# ==========================================
# 第3步: 运行VGGSfM三维重建
# ==========================================
echo ""
echo "[3/5] 运行VGGSfM稀疏三维重建..."

for extracted_dir in "$OUTPUT_DIR"/*; do
    if [ ! -d "$extracted_dir/rgb" ]; then
        continue
    fi
    
    bag_name=$(basename "$extracted_dir")
    echo "  处理: $bag_name"
    
    # 创建VGGSfM输入目录
    scene_dir="$OUTPUT_DIR/${bag_name}_sfm"
    mkdir -p "$scene_dir/images"
    
    # 复制RGB图像
    cp "$extracted_dir/rgb"/*_rgb.png "$scene_dir/images/" 2>/dev/null || true
    
    # 修改文件名为标准格式（00.png, 01.png等）
    cd "$scene_dir/images"
    i=0
    for f in *_rgb.png; do
        mv "$f" "$(printf "%02d.png" $i)" 2>/dev/null || true
        ((i++))
    done
    cd "$VGGSFM_DIR"
    
    echo "  运行SfM重建..."
    python3 demo.py SCENE_DIR="$scene_dir" SCENE_DIR="$scene_dir" \
        query_frame_num=1 \
        use_poselib=false \
        fine_tracking=false \
        query_method=sp 2>&1 | tail -20
    
    if [ -d "$scene_dir/sparse" ]; then
        echo "  ✓ SfM重建完成"
    fi
done

# ==========================================
# 第4步: 检测AprilTag并标定物体坐标
# ==========================================
echo ""
echo "[4/5] 检测AprilTag并标定物体坐标..."

for extracted_dir in "$OUTPUT_DIR"/*; do
    if [ ! -d "$extracted_dir/rgb" ]; then
        continue
    fi
    
    if [ ! -f "$extracted_dir/info/metadata.json" ]; then
        continue
    fi
    
    bag_name=$(basename "$extracted_dir")
    echo "  处理: $bag_name"
    
    # 运行AprilTag检测
    python3 /root/reconstruction_toolkit/apriltag_calibration.py \
        "$extracted_dir/info/metadata.json" \
        "$extracted_dir/rgb" \
        "$extracted_dir/depth" 2>&1 | tail -10
done

# ==========================================
# 第5步: 生成总结报告
# ==========================================
echo ""
echo "[5/5] 生成总结报告..."

cat > "$OUTPUT_DIR/RECONSTRUCTION_REPORT.md" << 'EOF'
# 三维重建和AprilTag标定报告

## 处理流程

1. **RGB-D数据提取**: 从ROS bag文件中提取RGB图像和深度数据
2. **VGGSfM重建**: 运行稀疏三维重建，获得相机轨迹和点云
3. **AprilTag检测**: 在RGB图像中检测AprilTag标记
4. **坐标标定**: 计算物体相对于AprilTag的三维坐标

## 输出说明

### 目录结构
```
reconstruction_output/
├── [bag_name]/
│   ├── rgb/           - RGB图像
│   ├── depth/         - 深度图像（如有）
│   ├── info/          - 相机参数和元数据
│   └── metadata.json  - 帧信息
├── [bag_name]_sfm/
│   ├── images/        - SfM输入图像
│   └── sparse/        - COLMAP格式的重建结果
│       ├── cameras.bin      - 相机内外参
│       ├── images.bin       - 图像和特征
│       └── points3D.bin     - 三维点云
└── apriltag_detections/
    └── *.png          - 检测可视化
```

### 坐标系定义
- **相机坐标系**: Z轴向前，X轴向右，Y轴向下
- **AprilTag坐标系**: 中心为原点，平面在XY平面上
- **世界坐标系**: 由第一个AprilTag定义

### 关键文件
- `metadata.json`: 帧同步信息和相机内参
- `calibration.json`: 物体的三维坐标和标定结果
- `cameras.bin`, `images.bin`, `points3D.bin`: COLMAP格式的SfM结果

## 使用建议

1. 检查`apriltag_detections/`中的可视化结果
2. 查验`metadata.json`中的相机内参是否正确
3. 使用`points3D.bin`可视化点云（推荐使用COLMAP Viewer）
4. 根据`calibration.json`获取物体的精确坐标
EOF

echo "  ✓ 报告生成完成"

# ==========================================
# 总结
# ==========================================
echo ""
echo "========================================"
echo "✓ 工作流完成！"
echo "========================================"
echo ""
echo "输出目录: $OUTPUT_DIR"
echo ""
echo "后续步骤:"
echo "1. 查看 apriltag_detections/ 中的检测结果"
echo "2. 检查各bag_name/sparse/ 中的三维重建点云"
echo "3. 使用 calibration.json 获取物体的三维坐标"
echo "4. （可选）使用COLMAP可视化查看重建结果"
echo ""
