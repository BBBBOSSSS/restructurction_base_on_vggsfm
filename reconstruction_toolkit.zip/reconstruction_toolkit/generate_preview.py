#!/usr/bin/env python3
"""
生成物体重建的静态图像
用于快速检查重建结果
"""

import open3d as o3d
import numpy as np
import json
import matplotlib.pyplot as plt
from pathlib import Path


def generate_views(recon_dir, output_file="reconstruction_preview.png"):
    """生成重建结果的多视角预览图"""
    recon_path = Path(recon_dir)
    
    print("加载点云数据...")
    
    # 加载点云
    obj0 = o3d.io.read_point_cloud(str(recon_path / "object_00.ply"))
    obj1 = o3d.io.read_point_cloud(str(recon_path / "object_01.ply"))
    table = o3d.io.read_point_cloud(str(recon_path / "table_plane.ply"))
    
    # 上色
    obj0.paint_uniform_color([1, 0, 0])      # 红色
    obj1.paint_uniform_color([0, 1, 0])      # 绿色
    table.paint_uniform_color([0.5, 0.5, 0.5])  # 灰色
    
    # 合并场景
    scene = obj0 + obj1 + table
    
    # 加载物体信息
    with open(recon_path / "objects_info.json", 'r') as f:
        info = json.load(f)
    
    # 创建可视化器（离屏渲染）
    vis = o3d.visualization.Visualizer()
    vis.create_window(visible=False, width=800, height=600)
    
    # 添加几何体
    vis.add_geometry(scene)
    
    # 设置渲染选项
    opt = vis.get_render_option()
    opt.point_size = 5.0
    opt.background_color = np.array([0.05, 0.05, 0.05])
    
    # 生成4个视角
    views = []
    view_configs = [
        ("正视图", [0, 0, -1], [0, -1, 0]),      # 从前往后看
        ("俯视图", [0, -1, 0], [0, 0, 1]),        # 从上往下看
        ("侧视图", [1, 0, 0], [0, -1, 0]),        # 从右往左看
        ("45度视图", [1, -1, -1], [0, -1, 0]),   # 斜视
    ]
    
    ctr = vis.get_view_control()
    
    for view_name, front, up in view_configs:
        print(f"渲染 {view_name}...")
        
        # 设置视角
        ctr.set_front(front)
        ctr.set_up(up)
        ctr.set_zoom(0.6)
        
        # 更新并捕获图像
        vis.poll_events()
        vis.update_renderer()
        
        # 捕获图像
        image = vis.capture_screen_float_buffer(do_render=True)
        views.append((view_name, np.asarray(image)))
    
    vis.destroy_window()
    
    # 创建多视角图
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('RGBD 桌面物体重建 - 多视角预览', fontsize=16, fontweight='bold')
    
    for idx, (view_name, img) in enumerate(views):
        ax = axes[idx // 2, idx % 2]
        ax.imshow(img)
        ax.set_title(view_name, fontsize=14, fontweight='bold')
        ax.axis('off')
    
    # 添加说明文本
    info_text = "检测到的物体:\n\n"
    for obj in info:
        color = "红色" if obj['id'] == 0 else "绿色"
        info_text += f"物体 {obj['id']} ({color}):\n"
        info_text += f"  点数: {obj['num_points']}\n"
        info_text += f"  中心: ({obj['center'][0]:.3f}, {obj['center'][1]:.3f}, {obj['center'][2]:.3f})m\n"
        info_text += f"  尺寸: {obj['extent'][0]*100:.1f}×{obj['extent'][1]*100:.1f}×{obj['extent'][2]*100:.1f}cm\n\n"
    
    fig.text(0.02, 0.02, info_text, fontsize=10, family='monospace',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
    
    plt.tight_layout()
    
    output_path = recon_path / output_file
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"\n✓ 预览图已保存: {output_path}")
    
    return output_path


def generate_simple_stats_image(recon_dir, output_file="objects_stats.png"):
    """生成简单的统计图表"""
    recon_path = Path(recon_dir)
    
    # 加载物体信息
    with open(recon_path / "objects_info.json", 'r') as f:
        info = json.load(f)
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Plot 1: Point cloud counts
    ax1 = axes[0]
    obj_ids = [f"Object{obj['id']}" for obj in info]
    point_counts = [obj['num_points'] for obj in info]
    colors_bar = ['red', 'green']
    
    ax1.bar(obj_ids, point_counts, color=colors_bar, alpha=0.7)
    ax1.set_ylabel('Points', fontsize=12)
    ax1.set_title('Point Cloud Counts', fontsize=14, fontweight='bold')
    ax1.grid(axis='y', alpha=0.3)
    
    for i, v in enumerate(point_counts):
        ax1.text(i, v + 500, str(v), ha='center', fontweight='bold')
    
    # Plot 2: Object dimensions
    ax2 = axes[1]
    extents = np.array([obj['extent'] for obj in info]) * 100  # Convert to cm
    
    x = np.arange(len(info))
    width = 0.25
    
    ax2.bar(x - width, extents[:, 0], width, label='Length(X)', color='red', alpha=0.7)
    ax2.bar(x, extents[:, 1], width, label='Width(Y)', color='green', alpha=0.7)
    ax2.bar(x + width, extents[:, 2], width, label='Height(Z)', color='blue', alpha=0.7)
    
    ax2.set_ylabel('Size (cm)', fontsize=12)
    ax2.set_title('Object Dimensions', fontsize=14, fontweight='bold')
    ax2.set_xticks(x)
    ax2.set_xticklabels([f"Object{obj['id']}" for obj in info])
    ax2.legend()
    ax2.grid(axis='y', alpha=0.3)
    
    # Plot 3: Object positions (top view)
    ax3 = axes[2]
    
    for obj in info:
        color = 'red' if obj['id'] == 0 else 'green'
        x, y, z = obj['center']
        
        # Draw object center
        ax3.scatter(x, y, s=500, c=color, alpha=0.6, edgecolors='black', linewidth=2)
        ax3.text(x, y, f"Obj{obj['id']}", ha='center', va='center', 
                fontweight='bold', fontsize=10)
        
        # Draw bounding box projection (XY plane top view)
        bbox_min = obj['bbox_min']
        bbox_max = obj['bbox_max']
        
        rect_x = [bbox_min[0], bbox_max[0], bbox_max[0], bbox_min[0], bbox_min[0]]
        rect_y = [bbox_min[1], bbox_min[1], bbox_max[1], bbox_max[1], bbox_min[1]]
        
        ax3.plot(rect_x, rect_y, color=color, linewidth=2, alpha=0.5)
    
    ax3.scatter(0, 0, s=200, c='yellow', marker='*', edgecolors='black', 
               linewidth=2, label='Camera', zorder=10)
    
    ax3.set_xlabel('X (m)', fontsize=12)
    ax3.set_ylabel('Y (m)', fontsize=12)
    ax3.set_title('Object Positions (Top View)', fontsize=14, fontweight='bold')
    ax3.grid(True, alpha=0.3)
    ax3.legend()
    ax3.axis('equal')
    
    plt.tight_layout()
    
    output_path = recon_path / output_file
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"✓ Statistics saved: {output_path}")
    
    return output_path


if __name__ == "__main__":
    recon_dir = "/root/reconstruction_toolkit/output/20260205_163837/rgbd_reconstruction"
    
    print("=" * 60)
    print("Generating reconstruction preview images...")
    print("=" * 60)
    
    # Generate statistics charts (no Open3D rendering needed)
    stats_img = generate_simple_stats_image(recon_dir)
    
    print("\n" + "=" * 60)
    print("Done!")
    print("=" * 60)
    print(f"\nView statistics: {stats_img}")
    print("\nFor 3D visualization, run:")
    print("  python view_objects.py")
