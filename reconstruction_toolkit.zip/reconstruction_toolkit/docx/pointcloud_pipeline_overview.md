# RealSense RGB-D + AprilTag + VGGSfM 点云重建技术路线说明

本文档梳理本项目从 RealSense 采集数据到点云生成、分割、坐标系对齐，以及基于 VGGSfM 的神经 SfM 加密点云与最终可视化交付的完整技术路线。

---

## 阶段 1：数据解耦与标准化 (Data Preparation)

**核心脚本**：`extract_rgbd_from_bag.py`

**输入**：原始 `.bag` 记录文件（包含对齐的流数据，如 RGB/Depth/CameraInfo）。

**目标**：解决 ROS 数据格式的封闭性，将“动态传感器流”转换为“静态时间序列数据集”。

**关键产物**：

- `rgb/`：RGB 帧序列（按帧编号保存）
- `depth/`：深度帧序列（按帧编号保存）
- `info/metadata.json`：包含相机内参、分辨率、时间戳等元信息

**关键点**：

- **每帧携带准确内参 (Intrinsics)**。这是后续反投影（2D -> 3D）的基础；内参错误会导致尺度/形状畸变，后续所有几何估计都会劣化。

### 代码定位（算法落点）

- ROS bag 读取与遍历：`reconstruction_toolkit/extract_rgbd_from_bag.py:16` 的 `extract_rgbd()` 内使用 `rosbags.rosbag1.Reader` 并遍历 `reader.messages()`（`reconstruction_toolkit/extract_rgbd_from_bag.py:43`）。
- Image 消息解析（手工 unpack `sensor_msgs/Image`）：`reconstruction_toolkit/extract_rgbd_from_bag.py:106` 的 `parse_image_msg()`（按 encoding 还原 `rgb8/bgr8/16UC1` 等）。
- CameraInfo 解析与内参提取：`reconstruction_toolkit/extract_rgbd_from_bag.py:162` 的 `parse_camera_info()`（从 `K` 拆 `fx/fy/cx/cy`）。
- 元信息落盘：`reconstruction_toolkit/extract_rgbd_from_bag.py:87` 构造 `metadata`，并在 `reconstruction_toolkit/extract_rgbd_from_bag.py:95` 写入 `info/metadata.json`。

---

## 阶段 2：基于几何的场景解析 (Geometric Scene Parsing)

**核心脚本**：`rgbd_reconstruction.py`

该阶段对应“把像素与深度转换成物理空间中的结构”，并在点云层面对桌面与物体进行解析。

### 2.1 反投影 (Back-projection)

利用 Open3D 将单帧或多帧的 RGB + Depth 反投影为彩色点云。

### 2.2 桌面提取 (Plane Segmentation)

使用 RANSAC 拟合平面方程：

`Ax + By + Cz + D = 0`

该平面作为空间中的**基准面**（桌面），用于将桌面与桌面上方物体分离。

### 2.3 ROI 过滤 (Region of Interest)

通过距离阈值等规则过滤掉：

- 桌面以下的点
- 过远/噪声点

只保留桌面上的物体点云区域。

### 2.4 对象级聚类 (Object Clustering)

对“桌面上方点云”使用 DBSCAN 聚类：

- 不需要预设聚类数量
- 可根据密度自动识别互不相连的物体

**关键产物**：

- `object_XX.ply`：每个物体的独立点云
- `objects_info.json`：每个物体的中心、尺寸、AABB 等几何信息

### 代码定位（算法落点）

- 相机内参读取与 Open3D 内参对象：`reconstruction_toolkit/rgbd_reconstruction.py:32` 的 `load_camera_info()`，并在 `reconstruction_toolkit/rgbd_reconstruction.py:57` 构造 `o3d.camera.PinholeCameraIntrinsic`。
- 深度与 RGB 尺寸对齐（resize）：`reconstruction_toolkit/rgbd_reconstruction.py:88` 到 `reconstruction_toolkit/rgbd_reconstruction.py:92`。
- RGB-D 生成（深度尺度/截断）：`reconstruction_toolkit/rgbd_reconstruction.py:99` 的 `o3d.geometry.RGBDImage.create_from_color_and_depth(...)`（`depth_scale` 默认 1000、`depth_trunc` 默认 3m）。
- 反投影生成点云：`reconstruction_toolkit/rgbd_reconstruction.py:109` 的 `rgbd_to_pointcloud()` 内调用 `o3d.geometry.PointCloud.create_from_rgbd_image(...)`（`reconstruction_toolkit/rgbd_reconstruction.py:122`）。
- 多帧融合（直接叠加）、体素下采样与统计滤波：`reconstruction_toolkit/rgbd_reconstruction.py:158` 的 `reconstruct_multi_frame()`，其中 `voxel_down_sample`（`reconstruction_toolkit/rgbd_reconstruction.py:195`）和 `remove_statistical_outlier`（`reconstruction_toolkit/rgbd_reconstruction.py:199`）。
- 平面分割（RANSAC）：`reconstruction_toolkit/rgbd_reconstruction.py:209` 的 `detect_table_plane()` 内 `pcd.segment_plane(...)`（`reconstruction_toolkit/rgbd_reconstruction.py:228`）。
- 聚类分割（DBSCAN）：`reconstruction_toolkit/rgbd_reconstruction.py:254` 的 `segment_objects()` 内 `objects_pcd.cluster_dbscan(...)`（`reconstruction_toolkit/rgbd_reconstruction.py:270`）。
- 物体包围盒与中心：`reconstruction_toolkit/rgbd_reconstruction.py:295` 的 `get_axis_aligned_bounding_box()`，并在 `reconstruction_toolkit/rgbd_reconstruction.py:317` 写入 `objects_info.json`。
- 流水线串联：`reconstruction_toolkit/rgbd_reconstruction.py:374` 的 `full_pipeline()`（按 1 融合、2 平面、3 聚类、4 报告、5 可视化顺序调用）。

---

## 阶段 3：世界坐标系对齐 (Spatial Localization)

**核心脚本**：`apriltag_coordinate_system.py`

**问题背景**：相机坐标系不稳定。相机移动时，坐标原点/方向也随之变化，导致不同帧、不同视角下的结果无法直接对比与叠加。

**技术路线**：

- 在 RGB 序列中识别 AprilTag
- 估计 AprilTag 相对于相机的位姿
- 以 AprilTag 的中心建立绝对世界坐标系 (WCS)

**结果**：

- 将所有点云（桌面、单个物体、全景融合点云）统一变换到**以 Tag 中心为原点**的坐标系下。
- 使得不同帧、不同视角的数据具备可比性与可堆叠性，便于跨序列的测量、融合与复现。

**关键产物**：

- `rgbd_reconstruction/apriltag_frame/` 下的 `*_tag.ply`、`apriltag_info.json`、`objects_info_tag.json` 等

### 代码定位（算法落点）

- AprilTag 检测与位姿估计：`reconstruction_toolkit/apriltag_coordinate_system.py:83` 的 `detect_apriltag()` 内调用 `Detector.detect(..., estimate_tag_pose=True, camera_params=..., tag_size=...)`（`reconstruction_toolkit/apriltag_coordinate_system.py:98`）。
- 选择“最佳帧”（decision margin 最大）：`reconstruction_toolkit/apriltag_coordinate_system.py:107` 的 `find_apriltag_in_sequence()` 内维护 `max_decision_margin`（`reconstruction_toolkit/apriltag_coordinate_system.py:124` 到 `reconstruction_toolkit/apriltag_coordinate_system.py:135`）。
- 可视化角点与三轴投影：`reconstruction_toolkit/apriltag_coordinate_system.py:161` 的 `visualize_detection()`（三轴投影计算见 `reconstruction_toolkit/apriltag_coordinate_system.py:197` 到 `reconstruction_toolkit/apriltag_coordinate_system.py:223`）。
- 坐标系变换公式（核心数学）：`reconstruction_toolkit/apriltag_coordinate_system.py:231` 的 `transform_to_tag_frame()` 实现 `p_tag = R^T * (p_cam - t)`（`reconstruction_toolkit/apriltag_coordinate_system.py:243` 到 `reconstruction_toolkit/apriltag_coordinate_system.py:257`）。
- 点云/物体信息批量转换与落盘：`reconstruction_toolkit/apriltag_coordinate_system.py:283` 的 `recompute_objects_in_tag_frame()`，读取 `objects_info.json`（`reconstruction_toolkit/apriltag_coordinate_system.py:295`），转换点云（`reconstruction_toolkit/apriltag_coordinate_system.py:303`），并写入 `apriltag_frame/`（点云写出见 `reconstruction_toolkit/apriltag_coordinate_system.py:361`，JSON 写出见 `reconstruction_toolkit/apriltag_coordinate_system.py:371` 和 `reconstruction_toolkit/apriltag_coordinate_system.py:383`）。
- 总控入口：`reconstruction_toolkit/apriltag_coordinate_system.py:392` 的 `full_pipeline()`（先检测，再可视化，再转换与落盘）。

### 轴向修正（dt-apriltags 坐标轴映射实验脚本）

如果你发现 `dt_apriltags` 给出的 `pose_R/pose_t` 的轴向和你期望的不一致，这里有一套“验证与修正”的实验脚本链路（不属于主流水线，但用于确认坐标轴定义）：

- 枚举多种轴映射并打印投影方向：`reconstruction_toolkit/test_axis_mapping.py:47` 定义 configs，`reconstruction_toolkit/test_axis_mapping.py:55` 循环测试。
- 用角点方向直接确定“右/下”像素方向：`reconstruction_toolkit/draw_correct_axes.py:34` 角点顺序假设，`reconstruction_toolkit/draw_correct_axes.py:37` 到 `reconstruction_toolkit/draw_correct_axes.py:44` 计算 `right_vec/down_vec`。
- 试验性修正（示例：翻转 Y 列）：`reconstruction_toolkit/fix_axes_final.py:141` 到 `reconstruction_toolkit/fix_axes_final.py:144` 构造 `R_corrected` 并写 JSON（`reconstruction_toolkit/fix_axes_final.py:166`）。
- 最终映射说明与矩阵重排：`reconstruction_toolkit/apriltag_final_fix.py:44` 到 `reconstruction_toolkit/apriltag_final_fix.py:54` 给出映射含义，`reconstruction_toolkit/apriltag_final_fix.py:106` 到 `reconstruction_toolkit/apriltag_final_fix.py:110` 构造 `R_corrected`，并在 `reconstruction_toolkit/apriltag_final_fix.py:132` 写出 `apriltag_pose_final_correct.json`。

---

## 阶段 4：深度特征重建 (Neural SfM)

**核心脚本**：VGGSfM (`demo.py`)

该阶段是“视觉增强线”，与 RGB-D 的差异在于：

- **RGB-D**：依赖深度相机的深度测量（结构光/ToF 等）
- **VGGSfM**：依赖多视角图像的跨帧跟踪与几何约束（神经 SfM）

### 4.1 基本输出（稀疏 SfM）

VGGSfM 最终会落盘 COLMAP 格式的稀疏重建结果：

- `cameras.bin`
- `images.bin`
- `points3D.bin`

### 4.2 密集化策略（加密点云）

通过参数 `extra_pt_pixel_interval` 在图像上做网格采样：

- 不仅依赖传统“角点/特征点”
- 利用模型的跨帧 Track 能力，跟踪这些采样点并三角化得到 3D
- 通过 `concat_extra_points=True` 将额外点拼接到点云中

**意义**：

- 点数可显著高于传统 SIFT/SfM 的稀疏点云
- 更容易勾勒出物体轮廓与表面结构（但仍属于 SfM 级别点云，并非真正的网格/体素重建）

### 代码定位（算法落点）

> 该阶段代码位于 `vggsfm` 子仓库（路径是 `/root/vggsfm`），这里按你实际运行到的逻辑标注关键入口。

- 主入口与 Runner 调度：`/root/vggsfm/demo.py:17` 的 `demo_fn()` 创建 `VGGSfMRunner` 并调用 `vggsfm_runner.run(...)`（`/root/vggsfm/demo.py:71`）。
- “稀疏 SfM”主流程：`/root/vggsfm/vggsfm/runners/runner.py:292` 的 `sparse_reconstruct()`（注释里明确包含 pose、track、triangulation、BA 等步骤）。
- 三角化与 BA：`/root/vggsfm/vggsfm/runners/runner.py:488` 到 `runner.py:514` 调用 `self.triangulator(...)` 并输出 `reconstruction/points3D`。
- 加密点云（extra points）开关：`/root/vggsfm/vggsfm/runners/runner.py:519` 判断 `extra_pt_pixel_interval > 0` 后进入 `triangulate_extra_points()`（`/root/vggsfm/vggsfm/runners/runner.py:520`）。
- 网格采样与跨帧跟踪：`/root/vggsfm/vggsfm/runners/runner.py:661` 通过 `generate_grid_samples(..., pixel_interval=self.cfg.extra_pt_pixel_interval)` 生成采样点；`/root/vggsfm/vggsfm/runners/runner.py:680` 调用 `predict_tracks(...)` 对这些采样点做跨帧跟踪。
- 额外点三角化与拼接：`/root/vggsfm/vggsfm/runners/runner.py:709` 到 `runner.py:716` 三角化；若 `concat_extra_points=True`，在 `runner.py:549` 到 `runner.py:564` 将额外点写入 `reconstruction` 并拼接到 `points3D`。
- 参数默认值（可作为配置来源）：`/root/vggsfm/cfgs/demo.yaml:65` 到 `demo.yaml:67` 定义 `concat_extra_points/extra_pt_pixel_interval/extra_by_neighbor`。

---

## 阶段 5：集成与可视化 (Final Integration)

**核心脚本**：`visualize_reconstruction.py`

### 5.1 数据转化

通过 `pycolmap` 将 VGGSfM 的 COLMAP 二进制输出转换为通用点云格式：

- 导出 `.ply` 便于用 CloudCompare / MeshLab 等工具直接查看与测量

### 5.2 交付物

- **静态模型**：`.ply` 点云，用于工程测量/检查
- **动态展示**：HTML 查看器（便于演示与远程协作）
- **报告**：`reconstruction_report.md`（记录相机参数、分割结果、对象统计等）

### 代码定位（算法落点）

- 读取 COLMAP 模型与导出 PLY：`reconstruction_toolkit/visualize_reconstruction.py:12` 的 `export_ply()` 使用 `pycolmap.Reconstruction(...)` 并写二进制 little-endian PLY。
- 重建统计（相机/注册图像/点云范围/误差/track length）：`reconstruction_toolkit/visualize_reconstruction.py:59` 的 `print_reconstruction_info()`。
- HTML 查看器生成：`reconstruction_toolkit/visualize_reconstruction.py:119` 的 `generate_html_viewer()`（基于 three.js 的 `PLYLoader` 加载）。

---

## 备注与常见限制

- RGB-D 多帧融合如果未做位姿估计/配准，移动相机会导致点云重影与模糊。
- AprilTag 的 **tag_size** 与 **tag family** 必须与实际一致，否则坐标系尺度与方向会错误。
- VGGSfM 的“加密点”仍受视角重叠、纹理丰富度、运动模糊等因素影响；点数上升不等于几何一定正确，需要结合重投影误差与可视化检查。
