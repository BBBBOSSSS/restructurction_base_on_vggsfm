#!/usr/bin/env python3
"""
环境检查和配置验证脚本
"""
import sys
import subprocess
import importlib


def check_module(module_name, pip_name=None, optional=False):
    """检查Python模块是否可用"""
    try:
        importlib.import_module(module_name)
        print(f"  ✓ {module_name}")
        return True
    except ImportError:
        status = "✗" if not optional else "⚠"
        print(f"  {status} {module_name}" + (f" (optional)" if optional else ""))
        if pip_name and not optional:
            print(f"     → 安装: pip install {pip_name}")
        return False


def check_command(cmd_name):
    """检查命令行工具是否可用"""
    try:
        subprocess.run([cmd_name, "--version"], capture_output=True, check=True)
        print(f"  ✓ {cmd_name}")
        return True
    except:
        print(f"  ✗ {cmd_name}")
        return False


def main():
    print("="*60)
    print("VGGSfM + AprilTag工作流环境检查")
    print("="*60)
    
    all_ok = True
    
    # 检查Python版本
    print("\n[必需] Python版本:")
    if sys.version_info >= (3, 8):
        print(f"  ✓ Python {sys.version.split()[0]}")
    else:
        print(f"  ✗ Python版本过低: {sys.version.split()[0]} (需要3.8+)")
        all_ok = False
    
    # 检查必需的Python模块
    print("\n[必需] Python模块:")
    required_modules = [
        ("torch", "torch OR pytorch"),
        ("cv2", "opencv-python"),
        ("numpy", "numpy"),
        ("scipy", "scipy"),
    ]
    
    for module, pip in required_modules:
        if not check_module(module, pip):
            all_ok = False
    
    # 检查可选的Python模块
    print("\n[可选] Python模块:")
    optional_modules = [
        ("rosbag", "rosbag (需要ROS环境)"),
        ("pupil_apriltags", "pupil-apriltags"),
        ("colmap", "Not available via pip (需要编译安装)"),
    ]
    
    for module, pip in optional_modules:
        check_module(module, pip, optional=True)
    
    # 检查VGGSfM安装
    print("\n[检查] VGGSfM环境:")
    vggsfm_dirs = [
        "/root/vggsfm/vggsfm",
        "/root/vggsfm/ckpt",
        "/root/vggsfm/examples",
    ]
    
    for d in vggsfm_dirs:
        try:
            import os
            if os.path.exists(d):
                print(f"  ✓ {d}")
            else:
                print(f"  ✗ {d}")
                all_ok = False
        except:
            pass
    
    # 检查数据目录
    print("\n[检查] 数据目录:")
    import os
    data_dir = "/root/vggsfm/data"
    if os.path.exists(data_dir):
        bag_files = list(os.path.basename(f) for f in __import__('glob').glob(f"{data_dir}/*.bag"))
        if bag_files:
            print(f"  ✓ {data_dir}")
            for bf in bag_files:
                print(f"    - {bf}")
        else:
            print(f"  ⚠ {data_dir} (未找到.bag文件)")
    else:
        print(f"  ✗ {data_dir} (目录不存在)")
    
    # 验证脚本
    print("\n[检查] 工作流脚本:")
    scripts = [
        "/root/extract_rgbd_from_bag.py",
        "/root/apriltag_calibration.py",
        "/root/object_annotator.py",
    ]
    
    for script in scripts:
        if os.path.exists(script):
            print(f"  ✓ {script}")
        else:
            print(f"  ✗ {script}")
            all_ok = False
    
    # 总结
    print("\n" + "="*60)
    if all_ok:
        print("✓ 环境检查完成！所有必需组件已安装")
        print("\n立即开始:")
        print("  1. 将bag文件放入: /root/vggsfm/data/")
        print("  2. 运行工作流: bash /root/run_reconstruction_pipeline.sh")
        print("\n更多信息请看: /root/WORKFLOW_README.md")
    else:
        print("⚠ 环境检查发现问题，请安装缺失的依赖")
        print("\n  推荐安装:")
        print("  pip install pupil-apriltags")
        if not check_module("rosbag", "", True):
            print("  # ROS bag支持需要ROS环境")
    
    print("="*60)


if __name__ == "__main__":
    main()
