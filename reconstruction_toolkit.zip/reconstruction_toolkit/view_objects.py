#!/usr/bin/env python3
"""
简单查看重建物体的脚本
用不同颜色高亮显示检测到的物体
"""

import open3d as o3d
import numpy as np
import json
from pathlib import Path


def view_objects(recon_dir):
    """查看物体重建结果"""
    recon_path = Path(recon_dir)
    
    print("=" * 60)
    print("加载重建结果...")
    print("=" * 60)
    
    # 加载点云
    obj0 = o3d.io.read_point_cloud(str(recon_path / "object_00.ply"))
    obj1 = o3d.io.read_point_cloud(str(recon_path / "object_01.ply"))
    table = o3d.io.read_point_cloud(str(recon_path / "table_plane.ply"))
    
    # 给物体上鲜艳的颜色
    obj0.paint_uniform_color([1, 0, 0])      # 红色 - 大物体
    obj1.paint_uniform_color([0, 1, 0])      # 绿色 - 小物体
    table.paint_uniform_color([0.5, 0.5, 0.5])  # 灰色 - 桌面
    
    # 加载物体信息
    with open(recon_path / "objects_info.json", 'r') as f:
        info = json.load(f)
    
    print("\n检测到的物体:")
    for obj in info:
        color = "红色" if obj['id'] == 0 else "绿色"
        print(f"\n物体 {obj['id']} ({color}):")
        print(f"  点数: {obj['num_points']}")
        print(f"  中心坐标: ({obj['center'][0]:.3f}, {obj['center'][1]:.3f}, {obj['center'][2]:.3f}) 米")
        print(f"  物体尺寸: {obj['extent'][0]*100:.1f} × {obj['extent'][1]*100:.1f} × {obj['extent'][2]*100:.1f} cm")
    
    # 创建边界框
    geometries = []
    
    # 添加坐标轴（更大更明显）
    coordinate_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(
        size=0.3, origin=[0, 0, 0]
    )
    geometries.append(coordinate_frame)
    
    # 添加点云
    geometries.append(table)
    geometries.append(obj0)
    geometries.append(obj1)
    
    # 为每个物体添加边界框和中心标记
    for i, obj in enumerate(info):
        # 边界框
        bbox_min = np.array(obj['bbox_min'])
        bbox_max = np.array(obj['bbox_max'])
        bbox = o3d.geometry.AxisAlignedBoundingBox(bbox_min, bbox_max)
        
        if obj['id'] == 0:
            bbox.color = (1, 0, 0)  # 红色边界框
        else:
            bbox.color = (0, 1, 0)  # 绿色边界框
        
        geometries.append(bbox)
        
        # 中心位置标记球
        center_sphere = o3d.geometry.TriangleMesh.create_sphere(radius=0.02)
        center_sphere.translate(obj['center'])
        
        if obj['id'] == 0:
            center_sphere.paint_uniform_color([1, 0, 0])
        else:
            center_sphere.paint_uniform_color([0, 1, 0])
        
        center_sphere.compute_vertex_normals()
        geometries.append(center_sphere)
    
    print("\n" + "=" * 60)
    print("可视化说明:")
    print("  - 红色点云 + 红色框 = 物体0 (大物体, 34cm×24cm×15cm)")
    print("  - 绿色点云 + 绿色框 = 物体1 (小物体, 15cm×19cm×10cm)")
    print("  - 灰色点云 = 桌面")
    print("  - 彩色坐标轴 = 相机坐标系原点")
    print("  - 红/绿色球 = 物体中心位置")
    print("\n操作说明:")
    print("  - 鼠标左键拖拽: 旋转视角")
    print("  - 鼠标右键拖拽: 平移")
    print("  - 鼠标滚轮: 缩放")
    print("  - 按 H: 显示帮助")
    print("  - 按 R: 重置视角")
    print("  - 按 Q 或 ESC: 退出")
    print("=" * 60)
    
    # 可视化
    vis = o3d.visualization.Visualizer()
    vis.create_window(
        window_name="桌面物体检测 - Desktop Object Detection",
        width=1600,
        height=900
    )
    
    for geom in geometries:
        vis.add_geometry(geom)
    
    # 设置渲染选项
    opt = vis.get_render_option()
    opt.point_size = 3.0  # 增大点的大小
    opt.background_color = np.array([0.1, 0.1, 0.1])  # 深灰色背景
    
    # 调整视角
    ctr = vis.get_view_control()
    ctr.set_zoom(0.8)
    
    vis.run()
    vis.destroy_window()


if __name__ == "__main__":
    recon_dir = "/root/reconstruction_toolkit/output/20260205_163837/rgbd_reconstruction"
    view_objects(recon_dir)
