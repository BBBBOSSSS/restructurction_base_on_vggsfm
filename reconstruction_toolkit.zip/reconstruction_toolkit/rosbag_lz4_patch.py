#!/usr/bin/env python3
"""
为rosbag添加lz4压缩支持的patch
"""
import lz4.frame

def patch_rosbag_lz4():
    """为rosbag库添加lz4支持"""
    try:
        import rosbag.bag as bag_module
        
        # 保存原始函数
        original_decompress_chunk = bag_module._decompress_chunk if hasattr(bag_module, '_decompress_chunk') else None
        
        # 定义新的decompress_chunk函数
        def _decompress_chunk(data, compression_type):
            if compression_type == 0:  # No compression
                return data
            elif compression_type == 1:  # BZ2
                import bz2
                return bz2.decompress(data)
            elif compression_type == 2:  # LZ4
                return lz4.frame.decompress(data)
            else:
                raise Exception(f'Unknown compression type: {compression_type}')
        
        # 猴补丁
        bag_module._decompress_chunk = _decompress_chunk
        
        # 也要处理Chunk类
        if hasattr(bag_module, 'Chunk'):
            Chunk = bag_module.Chunk
            if hasattr(Chunk, '__init__'):
                original_init = Chunk.__init__
                
                def patched_init(self, *args, **kwargs):
                    original_init(self, *args, **kwargs)
                
                Chunk.__init__ = patched_init
        
        print("✓ rosbag lz4 patch installed")
        return True
        
    except Exception as e:
        print(f"✗ Failed to patch rosbag: {e}")
        return False

if __name__ == "__main__":
    patch_rosbag_lz4()
