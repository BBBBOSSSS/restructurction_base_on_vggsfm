#!/usr/bin/env python3
"""
使用旋转矩阵正确计算坐标轴
dt-apriltags坐标系：X右，Y上，Z出
目标坐标系：X右，Y下，Z出
"""
import cv2
import numpy as np
from dt_apriltags import Detector
import json

with open('output/20260205_163837/info/metadata.json', 'r') as f:
    metadata = json.load(f)
rgb_K = metadata['camera_info']['rgb']['K']
fx, fy = rgb_K[0], rgb_K[4]
cx, cy = rgb_K[2], rgb_K[5]

TAG_SIZE = 0.161
detector = Detector(families='tag16h5', nthreads=4, quad_decimate=1.0)

img = cv2.imread('output/20260205_163837/rgb/000091.png', cv2.IMREAD_GRAYSCALE)
img_color = cv2.imread('output/20260205_163837/rgb/000091.png')
h, w = img.shape

results = detector.detect(img, estimate_tag_pose=True, camera_params=[fx, fy, cx, cy], tag_size=TAG_SIZE)
tag6 = [d for d in results if d.tag_id == 6][0]

pose_R = tag6.pose_R
pose_t = tag6.pose_t.flatten()
center = tag6.center

print("Pose:")
print(f"t = {pose_t}")
print(f"R =\n{pose_R}")
print(f"Center = {center}")
print()

axis_len = TAG_SIZE * 0.4

def project(pt):
    if pt[2] > 0:
        u = int(fx * pt[0] / pt[2] + cx)
        v = int(fy * pt[1] / pt[2] + cy)
        return (u, v)
    return None

# dt-apriltags使用: X右，Y上，Z出
# 从测试结果看：他们的X→图像下，Y→图像下，Z→图像右
# 推测：我们的X（右）应该对应他们的Z，我们的Y（下）应该对应他们的X

# 测试配置1: X=dt_Z, Y=dt_X, Z=dt_Y
axis_3d_tag_config1 = np.array([
    [0, 0, 0],                  # 原点
    [0, 0, axis_len],          # X轴：dt_Z
    [axis_len, 0, 0],          # Y轴：dt_X
    [0, axis_len, 0]           # Z轴：dt_Y
])

# 测试配置2: X=-dt_Z, Y=dt_X, Z=dt_Y  
axis_3d_tag_config2 = np.array([
    [0, 0, 0],
    [0, 0, -axis_len],         # X轴：-dt_Z 
    [axis_len, 0, 0],          # Y轴：dt_X
    [0, axis_len, 0]           # Z轴：dt_Y
])

print("===== 测试配置1: X=Z, Y=X, Z=Y =====")
axis_3d_cam = (pose_R @ axis_3d_tag_config1.T).T + pose_t
axis_2d = [project(pt) for pt in axis_3d_cam]
print("Axis points config1:")
for name, pt in zip(['O', 'X', 'Y', 'Z'], axis_2d):
    print(f"  {name}: {pt}")

print("\n===== 测试配置2: X=-Z, Y=X, Z=Y =====")
axis_3d_cam = (pose_R @ axis_3d_tag_config2.T).T + pose_t
axis_2d = [project(pt) for pt in axis_3d_cam]
print("Axis points config2:")
for name, pt in zip(['O', 'X', 'Y', 'Z'], axis_2d):
    print(f"  {name}: {pt}")

# 使用配置2来绘制
axis_3d_tag = axis_3d_tag_config2

# 转到相机坐标系
axis_3d_cam = (pose_R @ axis_3d_tag.T).T + pose_t

# 投影到图像
def project(pt):
    if pt[2] > 0:
        u = int(fx * pt[0] / pt[2] + cx)
        v = int(fy * pt[1] / pt[2] + cy)
        return (u, v)
    return None

axis_2d = [project(pt) for pt in axis_3d_cam]

print("Axis points:")
names = ['Origin', 'X', 'Y', 'Z']
for name, pt, pt3d in zip(names, axis_2d, axis_3d_cam):
    print(f"  {name}: 2D={pt}, 3D_cam={pt3d}")

center_px = (int(center[0]), int(center[1]))

# 绘制
cv2.circle(img_color, center_px, 10, (0, 255, 255), -1)

if all(p is not None for p in axis_2d):
    origin = axis_2d[0]
    
    # X轴 - 红色（向右）
    cv2.arrowedLine(img_color, origin, axis_2d[1], (0, 0, 255), 4, tipLength=0.15)
    cv2.putText(img_color, "X", (axis_2d[1][0]+5, axis_2d[1][1]+5), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
    
    # Y轴 - 绿色（向下）
    cv2.arrowedLine(img_color, origin, axis_2d[2], (0, 255, 0), 4, tipLength=0.15)
    cv2.putText(img_color, "Y", (axis_2d[2][0]+5, axis_2d[2][1]+5), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    
    # Z轴 - 蓝色（向外）
    cv2.arrowedLine(img_color, origin, axis_2d[3], (255, 0, 0), 4, tipLength=0.15)
    cv2.putText(img_color, "Z", (axis_2d[3][0]-30, axis_2d[3][1]-5), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

cv2.putText(img_color, f"Tag 6  Size: {TAG_SIZE*100:.1f}cm  Dist: {np.linalg.norm(pose_t)*100:.1f}cm", 
            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
cv2.putText(img_color, f"Frame: 91  Margin: {tag6.decision_margin:.1f}", 
            (10, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 2)
cv2.putText(img_color, "X=right(red)  Y=down(green)  Z=out(blue)", (10, h-10), 
            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

cv2.imwrite("apriltag_correct.jpg", img_color)
print(f"\nSaved: apriltag_correct.jpg")

# 同时保存到输出目录
import os
out_dir = "output/20260205_163837/rgbd_reconstruction/apriltag_frame"
os.makedirs(out_dir, exist_ok=True)
cv2.imwrite(f"{out_dir}/apriltag_correct.jpg", img_color)

# 保存正确的位姿（Y轴已翻转）
# 正确的旋转矩阵：Y列取反
R_corrected = pose_R.copy()
R_corrected[:, 1] = -R_corrected[:, 1]  # 翻转Y列

pose_info = {
    'tag_id': 6,
    'tag_family': 'tag16h5',
    'tag_size_m': TAG_SIZE,
    'frame': 91,
    'tvec': pose_t.tolist(),
    'R': R_corrected.tolist(),
    'R_original_apriltags': pose_R.tolist(),
    'distance_m': float(np.linalg.norm(pose_t)),
    'center_px': center.tolist(),
    'decision_margin': float(tag6.decision_margin),
    'coordinate_system': {
        'X': 'right (along tag edge)',
        'Y': 'down (along tag edge)',
        'Z': 'out of tag surface toward camera',
        'origin': 'tag center',
        'note': 'Y axis flipped from dt-apriltags convention (they use Y-up, we use Y-down)'
    }
}

with open(f"{out_dir}/apriltag_pose_correct.json", 'w') as f:
    json.dump(pose_info, f, indent=2)
print(f"Saved: {out_dir}/apriltag_pose_correct.json")

print("\n✓ 坐标系已修正: X向右, Y向下, Z垂直纸面向外")
