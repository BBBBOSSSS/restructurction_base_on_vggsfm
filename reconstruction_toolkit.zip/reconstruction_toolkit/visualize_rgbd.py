#!/usr/bin/env python3
"""
简单的Open3D可视化脚本
用于在GUI中查看重建结果
"""

import open3d as o3d
import json
import argparse
from pathlib import Path
import numpy as np


def visualize_reconstruction(recon_dir: str):
    """可视化重建结果"""
    recon_path = Path(recon_dir)
    
    print("加载重建结果...")
    
    # 加载点云
    combined_pcd = o3d.io.read_point_cloud(str(recon_path / "combined_pointcloud.ply"))
    table_pcd = o3d.io.read_point_cloud(str(recon_path / "table_plane.ply"))
    objects_colored = o3d.io.read_point_cloud(str(recon_path / "all_objects_colored.ply"))
    
    # 加载物体信息
    with open(recon_path / "objects_info.json", 'r') as f:
        objects_info = json.load(f)
    
    print(f"\n检测到 {len(objects_info)} 个物体:")
    for obj in objects_info:
        print(f"  物体 {obj['id']}: 中心=({obj['center'][0]:.3f}, {obj['center'][1]:.3f}, {obj['center'][2]:.3f})m, "
              f"尺寸=({obj['extent'][0]*100:.1f}×{obj['extent'][1]*100:.1f}×{obj['extent'][2]*100:.1f})cm")
    
    # 创建可视化元素
    geometries = []
    
    # 添加坐标系
    coordinate_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(
        size=0.2, origin=[0, 0, 0]
    )
    geometries.append(coordinate_frame)
    
    # 添加桌面（灰色透明）
    table_pcd.paint_uniform_color([0.8, 0.8, 0.8])
    geometries.append(table_pcd)
    
    # 添加物体（彩色）
    geometries.append(objects_colored)
    
    # 为每个物体添加边界框和文字标签
    for obj in objects_info:
        # 创建边界框
        bbox_min = np.array(obj['bbox_min'])
        bbox_max = np.array(obj['bbox_max'])
        
        # 使用Open3D的AxisAlignedBoundingBox
        bbox = o3d.geometry.AxisAlignedBoundingBox(bbox_min, bbox_max)
        bbox.color = (1, 0, 0)  # 红色边界框
        geometries.append(bbox)
        
        # 在物体中心创建小球标记
        center_sphere = o3d.geometry.TriangleMesh.create_sphere(radius=0.01)
        center_sphere.translate(obj['center'])
        center_sphere.paint_uniform_color([1, 0, 0])  # 红色
        geometries.append(center_sphere)
    
    print("\n可视化控制:")
    print("  - 鼠标拖拽: 旋转视角")
    print("  - 鼠标滚轮: 缩放")
    print("  - 按 Q/ESC: 退出")
    print("  - 按 H: 显示帮助")
    
    # 可视化
    o3d.visualization.draw_geometries(
        geometries,
        window_name="RGBD Desktop Reconstruction - 桌面物体三维重建",
        width=1600,
        height=900,
        left=50,
        top=50,
        point_show_normal=False
    )


def main():
    parser = argparse.ArgumentParser(description="可视化RGBD重建结果")
    parser.add_argument(
        "recon_dir", 
        type=str, 
        nargs='?',
        default="/root/reconstruction_toolkit/output/20260205_163837/rgbd_reconstruction",
        help="重建结果目录（包含ply和json文件）"
    )
    
    args = parser.parse_args()
    visualize_reconstruction(args.recon_dir)


if __name__ == "__main__":
    main()
